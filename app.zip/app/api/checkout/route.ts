import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase-server";
import { createAdminClient } from "@/lib/supabase-admin";
import { criarCobranca } from "@/lib/asaas";
import { decidirContratacao, type AssinaturaResumo } from "@/lib/assinatura";
import { encerrarAssinaturas } from "@/lib/assinatura-server";
import { criticaDocumento, limparDocumento } from "@/lib/documento";
import { enviarEmail } from "@/lib/email";
import { htmlCobrancaGerada } from "@/lib/emails-cliente";

/** cria a assinatura pendente e a cobrança Asaas para um plano */
export async function POST(req: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ erro: "não autenticado" }, { status: 401 });

  const { data: perfil } = await supabase
    .from("profiles")
    .select("tenant_id, email, tenants(nome, cpf_cnpj)")
    .eq("id", user.id)
    .maybeSingle();
  const tenantId = perfil?.tenant_id;
  if (!tenantId) return NextResponse.json({ erro: "workspace não encontrado" }, { status: 400 });

  let corpo: { plano_id: string; cpf_cnpj?: string };
  try {
    corpo = await req.json();
  } catch {
    return NextResponse.json({ erro: "corpo inválido" }, { status: 400 });
  }

  /**
   * O DOCUMENTO DO PAGADOR — o campo que faltava e travava tudo.
   *
   * O Asaas não cria cliente sem CPF/CNPJ. Vem do que a pessoa acabou de
   * digitar ou do que já está no escritório; sem nenhum dos dois, a resposta
   * diz exatamente isso, em vez de deixar o botão sem efeito.
   */
  const tCad = perfil?.tenants as { nome?: string; cpf_cnpj?: string } | { nome?: string; cpf_cnpj?: string }[] | null;
  const cad = Array.isArray(tCad) ? tCad[0] : tCad;
  const documento = limparDocumento(corpo.cpf_cnpj || cad?.cpf_cnpj || "");
  const critica = criticaDocumento(documento);
  if (critica) {
    return NextResponse.json({ erro: critica, falta_documento: true }, { status: 400 });
  }

  const { data: plano } = await supabase
    .from("planos")
    .select("id, nome, preco_centavos")
    .eq("id", corpo.plano_id)
    .maybeSingle();
  if (!plano) return NextResponse.json({ erro: "plano inválido" }, { status: 400 });

  /**
   * ═══════════════════════════════════════════════════════════════════════
   * UMA CONTA, UM PLANO — a regra que faltava, e o que ela conserta.
   *
   * Antes, cada clique em "Assinar" criava uma assinatura e uma cobrança. Numa
   * tarde de testes: 17 assinaturas na mesma conta e boletos abertos de dois
   * planos diferentes. O risco não é a bagunça da tabela — é o cliente pagar o
   * boleto errado e o webhook, obediente, ativar o plano que ele abandonou por
   * cima do que acabou de comprar.
   *
   * A decisão inteira é `decidirContratacao`, função pura e testada. Aqui só
   * executamos: reaproveitar a cobrança aberta do mesmo plano, encerrar as
   * pendentes que perderam a validade, e manter INTOCADO o plano pago que
   * ainda vale — os dias que sobram dele viram crédito na confirmação, e não
   * agora, porque cancelar acesso já pago de quem está pagando mais seria o
   * pior momento possível para acertar contas.
   * ═══════════════════════════════════════════════════════════════════════
   */
  const { data: minhas } = await supabase
    .from("assinaturas")
    .select("id, plano_id, status, valido_ate, asaas_id, checkout_url")
    .eq("tenant_id", tenantId);

  const plano_de_acao = decidirContratacao(plano.id, (minhas ?? []) as AssinaturaResumo[], new Date());
  const admin = createAdminClient();

  if (plano_de_acao.cancelar.length) {
    const r = await encerrarAssinaturas(admin ?? supabase, plano_de_acao.cancelar);
    if (r.avisos.length) console.error("[checkout] ao encerrar superadas:", r.avisos.join(" · "));
  }

  /**
   * CLICOU DE NOVO NO MESMO PLANO: devolve o link que já existe.
   *
   * Quem clica duas vezes está procurando o boleto que perdeu, não pedindo um
   * segundo. Emitir outro deixaria duas cobranças do mesmo valor na mão da
   * mesma pessoa — e alguém paga as duas.
   */
  if (plano_de_acao.acao === "reaproveitar" && plano_de_acao.reaproveitar?.checkout_url) {
    return NextResponse.json({
      ok: true,
      assinatura_id: plano_de_acao.reaproveitar.id,
      asaas_ativo: true,
      checkout_url: plano_de_acao.reaproveitar.checkout_url,
      reaproveitada: true,
      credito_dias: plano_de_acao.credito_dias,
      fatura_registrada: true,
      fatura_erro: null,
    });
  }

  /**
   * `valor_centavos` GRAVADO — a coluna que zerava o painel inteiro.
   *
   * Esta rota nunca gravou o valor. Como o painel de Negócio calcula MRR,
   * ticket, receita por plano e MRR em risco a partir dele, um assinante PRO
   * que acabou de pagar entrava como R$ 0 — e o painel mostrava receita zero
   * com dinheiro na conta.
   */
  const { data: assinatura, error: aErr } = await supabase
    .from("assinaturas")
    .insert({
      tenant_id: tenantId,
      plano_id: plano.id,
      status: "pendente",
      valor_centavos: plano.preco_centavos,
    })
    .select("id")
    .single();
  if (aErr) return NextResponse.json({ erro: aErr.message }, { status: 500 });

  const nome = cad?.nome ?? "Escritório";

  // guarda para a próxima cobrança: pedir o mesmo dado duas vezes é atrito
  if (documento !== cad?.cpf_cnpj) {
    await supabase.from("tenants").update({ cpf_cnpj: documento }).eq("id", tenantId);
  }

  const cobranca = await criarCobranca({
    nome,
    email: perfil?.email ?? user.email ?? "",
    cpf_cnpj: documento,
    valor_centavos: plano.preco_centavos,
    descricao: `Enquadria — ${plano.nome}`,
    externo: assinatura.id,
  });

  /**
   * O QUE ACONTECEU COM A FATURA sobe na resposta.
   *
   * Enquanto isto era só `console.error`, o bug do índice parcial (0040) durou
   * dias: a cobrança nascia, o e-mail saía, a fatura não gravava e a única
   * pista morava num log que ninguém abre. Falha silenciosa é falha que dura.
   */
  let faturaErro: string | null = null;

  if (cobranca.asaas_id || cobranca.checkout_url) {
    /**
     * O VENCIMENTO PRECISA SER GRAVADO AQUI — sem ele a cobrança nunca é cobrada.
     *
     * A escada de cobrança (pré-vencimento, D+1, D+5, D+10, em lib/reguas.ts)
     * é toda condicionada a `assinaturas.vencimento`. Este campo só era
     * gravado junto com `status: "ativa"`, na confirmação do pagamento — ou
     * seja, nunca existia enquanto a assinatura estava PENDENTE, que é
     * exatamente quem a escada existe para cobrar.
     *
     * Resultado: quem gerava o boleto pela tela de Planos e não pagava não
     * recebia nenhum lembrete. Nenhum. O Asaas devolve a data na criação da
     * cobrança; era só guardar.
     */
    const { error: eA } = await supabase
      .from("assinaturas")
      .update({
        asaas_id: cobranca.asaas_id ?? null,
        checkout_url: cobranca.checkout_url ?? null,
        vencimento: cobranca.vencimento ?? null,
      })
      .eq("id", assinatura.id);
    if (eA) console.error(`[checkout] assinatura ${assinatura.id} sem asaas_id/vencimento: ${eA.message}`);

    /**
     * A FATURA NASCE AQUI, não no webhook.
     *
     * O `PAYMENT_CREATED` chega em segundos — mas "em segundos" é depois de a
     * pessoa voltar para a tela. Sem esta linha, quem acabou de gerar a
     * cobrança abre a central de faturas e não vê nada, o que parece falha.
     *
     * O `upsert` por `asaas_id` (índice único na 0039) faz esta escrita e a do
     * webhook convergirem para a MESMA linha, não importa qual chegue antes.
     *
     * ─────────────────────────────────────────────────────────────────────
     * ESCREVE COM O CLIENTE DE SERVIÇO, e isto é a correção de um bug meu.
     *
     * A RLS de `faturas` dá ao escritório apenas SELECT — de propósito: se o
     * usuário pudesse escrever na própria tabela de faturas, poderia inserir
     * uma linha "paga" e liberar acesso sem pagar. Quem escreve fatura é o
     * servidor, a partir do que o Asaas confirma.
     *
     * Só que este trecho estava usando o cliente da SESSÃO. A RLS recusava a
     * escrita, o supabase-js devolve `{ error }` em vez de lançar, o código
     * ignorava, e o resultado era exatamente o relatado: o e-mail da cobrança
     * saía (ele vem depois) e a fatura não aparecia em lugar nenhum.
     * ─────────────────────────────────────────────────────────────────────
     */
    const { error: eF } = await (admin ?? supabase).from("faturas").upsert(
      {
        tenant_id: tenantId,
        assinatura_id: assinatura.id,
        plano_nome: plano.nome,
        asaas_id: cobranca.asaas_id ?? null,
        valor_centavos: plano.preco_centavos,
        status: "pendente",
        vencimento: cobranca.vencimento ?? null,
        link_pagamento: cobranca.checkout_url ?? null,
        link_boleto: cobranca.boleto_url ?? null,
        descricao: `Enquadria — ${plano.nome}`,
        atualizado_em: new Date().toISOString(),
      },
      { onConflict: "asaas_id" }
    );

    /* erro engolido foi a causa do bug; agora ele vai para o log E para a tela */
    if (eF) {
      faturaErro =
        eF.message + (admin ? "" : " — SUPABASE_SERVICE_ROLE_KEY ausente, a escrita foi tentada com a sessão e a RLS recusa");
      console.error(`[checkout] fatura NÃO registrada (assinatura ${assinatura.id}): ${faturaErro}`);
    }

    /**
     * O E-MAIL COM O LINK, AGORA — sem depender de webhook.
     *
     * Era o elo que faltava: a cobrança nascia e o contador ficava sem nada na
     * mão. Falha aqui não desfaz a contratação (o link já está na tela e na
     * central de faturas), então o erro só vai para o log.
     */
    const paraEmail = perfil?.email ?? user.email;
    if (paraEmail && cobranca.checkout_url) {
      try {
        const r = await enviarEmail({
          para: paraEmail,
          nome,
          assunto: `Sua cobrança do ${plano.nome} — Enquadria`,
          html: htmlCobrancaGerada({
            escritorio: { nome: "Enquadria" },
            plano: plano.nome,
            valor: (plano.preco_centavos / 100).toLocaleString("pt-BR", {
              style: "currency",
              currency: "BRL",
            }),
            vencimento: cobranca.vencimento
              ? new Date(`${cobranca.vencimento}T12:00:00`).toLocaleDateString("pt-BR")
              : null,
            link: cobranca.checkout_url,
          }),
          tag: "cobranca-gerada",
        });
        if (!r.enviado) {
          console.error(`[checkout] e-mail da cobrança não saiu: ${r.motivo}`);
        } else if (admin) {
          /**
           * RESERVA A CHAVE DA RÉGUA — senão o mesmo link vai duas vezes.
           *
           * A régua `cobranca_gerada` planeja e-mail para toda assinatura
           * pendente com link. Este envio aqui não passava por
           * `plataforma_envios`, então a trava não o enxergava: o contador
           * recebia o link na contratação e de novo na execução seguinte do
           * cron, com outro assunto. Gravando a mesma chave que a régua usa,
           * ela reconhece que já foi.
           */
          await admin.from("plataforma_envios").insert({
            tenant_id: tenantId,
            regra: "cobranca_gerada",
            chave_unica: `cobranca_gerada:${assinatura.id}`,
            para: paraEmail,
            assunto: `Sua cobrança do ${plano.nome} — Enquadria`,
            status: "enviado",
          });
        }
      } catch (e) {
        console.error("[checkout] e-mail da cobrança falhou:", e instanceof Error ? e.message : e);
      }
    }
  }

  /**
   * O TERCEIRO CASO, que a tela não cobria: Asaas LIGADO e sem link.
   *
   * Era aqui que o clique morria. Agora o motivo do Asaas sobe junto e vira
   * mensagem — a assinatura fica registrada como pendente de qualquer forma,
   * então nada se perde.
   */
  if (cobranca.ativo && !cobranca.checkout_url) {
    return NextResponse.json(
      {
        erro:
          cobranca.erro ??
          "A cobrança não foi gerada pelo Asaas e a assinatura ficou pendente. Tente de novo em instantes.",
        assinatura_id: assinatura.id,
        asaas_ativo: true,
      },
      { status: 502 }
    );
  }

  return NextResponse.json({
    ok: true,
    assinatura_id: assinatura.id,
    asaas_ativo: cobranca.ativo,
    checkout_url: cobranca.checkout_url ?? null,
    fatura_registrada: !faturaErro,
    fatura_erro: faturaErro,
    /* o que a tela precisa dizer: quantos dias pagos vêm junto, e que o plano
       anterior só sai de cena quando este for pago */
    credito_dias: plano_de_acao.credito_dias,
    substitui: plano_de_acao.ativa_atual?.plano_id ?? null,
  });
}
