/**
 * RODAR TUDO — um comando só, e o que sobra é o que precisa de tela.
 *
 *     node testes/rodar-tudo.mjs
 *
 * O que este arquivo faz e o que ele NÃO faz, sem meio-termo:
 *
 * FAZ (roda de verdade, aqui, sem banco e sem ninguém olhando):
 *   1. as três suítes de função pura — cockpit, motor, coleta;
 *   2. o CSV da massa passado pelo parser DE VERDADE do app, com as contagens
 *      de importadas/duplicadas/descartadas conferidas contra o esperado;
 *   3. triar() sobre as 45 empresas que entram, comparado com a distribuição
 *      de faixas registrada;
 *   4. decidir() nos 15 cenários e dDASsegregado()+decidir() nos 10 de
 *      segregação, contra os valores registrados;
 *   5. a memória de cálculo do laudo de uma análise SEGREGADA — o passo por
 *      anexo e a soma;
 *   6. no navegador: o curso estático (gate, progresso, certificado, tamanho
 *      do medalhão com e sem CSS, carimbo dos assets) e o formulário da coleta
 *      (validação, percentuais, corpo enviado).
 *
 * NÃO FAZ, e por isso continua na sua lista:
 *   · qualquer coisa que precise do Supabase — importar de fato, RLS, emitir
 *     laudo e termo, assinar, gravar coleta, cota de plano;
 *   · o comportamento real do .htaccess, que depende do Apache do HostGator;
 *   · salvar o certificado no perfil do LinkedIn;
 *   · julgamento de olho: se está bonito, se está claro, se cabe na tela.
 *
 * OS VALORES ESPERADOS SÃO GOLDEN, não recalculados na hora. Se eu recalculasse
 * com a mesma função que estou testando, o teste passaria sempre — inclusive
 * depois de alguém quebrar a função. Estes números vieram de uma execução
 * conferida e agora servem de trava: mudou, o teste acusa e alguém decide se a
 * mudança era para acontecer.
 */

import { execSync, spawnSync } from "child_process";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const RAIZ = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const TMP = path.join(RAIZ, ".tmp-rodar");
const CSV = process.env.MASSA_CSV || "/root/work/Enquadria_Massa_Empresas_Teste.csv";

let falhas = 0;
let passou = 0;
const linhas = [];

function ok(nome, condicao, detalhe) {
  if (condicao) {
    passou++;
    linhas.push(`ok    ${nome}`);
    console.log("ok   ", nome);
  } else {
    falhas++;
    const d = detalhe === undefined ? "" : ` → ${JSON.stringify(detalhe)}`;
    linhas.push(`FALHA ${nome}${d}`);
    console.log("FALHA", nome + d);
  }
}
function secao(t) {
  linhas.push("", `── ${t} ${"─".repeat(Math.max(0, 60 - t.length))}`);
  console.log(`\n── ${t} ${"─".repeat(Math.max(0, 60 - t.length))}`);
}

/* ====================================================== 0. COMPILAR ===== */
secao("Compilando o TypeScript das funções puras");
fs.rmSync(TMP, { recursive: true, force: true });
try {
  // tsconfig próprio em vez de flags soltas: `lib/reguas.ts` faz um
  // `await import("@/lib/email")` e o alias "@/" só existe com baseUrl+paths.
  // Sem isto o compilador para na primeira linha e nenhuma suíte roda.
  const ARQUIVOS = [
    // esign entra aqui porque `conteudoCanonico()` é o que vira HASH e vira
    // assinatura: se ele mudar de forma sem querer, o dano é silencioso
    "lib/motor.ts", "lib/laudo.ts", "lib/termo.ts", "lib/esign.ts", "lib/triagem.ts", "lib/cockpit.ts",
    "lib/premissas-padrao.ts", "lib/coleta.ts", "lib/csv.ts", "lib/cnpj.ts",
    "lib/plano.ts", "lib/potencial.ts", "lib/reguas.ts", "lib/reguas-indicacao.ts", "lib/janela.ts",
    "lib/emails-cliente.ts", "lib/erros-auth.ts", "lib/ajuda.ts", "lib/cobranca.ts", "lib/nps.ts",
    "lib/escritorio.ts", "lib/roteiro.ts", "lib/apontamentos.ts", "lib/abertura.ts", "lib/comparativo.ts",
    "lib/curso.ts", "lib/faturas.ts", "lib/filtro-faturas.ts", "lib/email-eventos.ts", "lib/documento.ts", "lib/assinatura.ts",
    "lib/negocio-calc.ts", "lib/projecao.ts", "lib/deriva.ts", "lib/gateway-limpeza.ts",
    "lib/recalculo.ts", "lib/slug.ts", "lib/reforma-publica.ts", "lib/radar.ts", "lib/radar-form.ts", "lib/radar-aviso.ts", "lib/digest.ts", "lib/reforma.ts",
    "lib/novidade.ts", "lib/mailer/templates.ts", "lib/entrega.ts", "lib/passos.ts", "lib/funil.ts",
    "lib/venda.ts", "lib/proposta.ts", "lib/entrega-garantida.ts",
    /* a receita única dos parâmetros congelados: três rotas gravam análise, e
       o que não for congelado aqui não aparece no laudo — que é prova e não
       recalcula nada */
    "lib/parametros-analise.ts",
    /* a proveniência das premissas: é o que o laudo AFIRMA sobre quem respondeu */
    "lib/origem-premissa.ts",
    /* a carteira da página pública /exemplo: afirmação verificável precisa de teste */
    "lib/exemplo.ts",
    /* a frase do produto: sete proposições foi o defeito, uma é a decisão */
    "lib/proposta-de-valor.ts",
    /* o relatório anual: números que vão para a mesa do cliente do contador */
    "lib/anuario.ts",
    /* a fusão com a base da Receita: ela completa lacuna e NÃO sobrescreve o
       que o escritório declarou — a regra antiga trocava CNAE, porte, situação
       e regime calada, e mudava a faixa da empresa sem dizer */
    "lib/receita.ts",
    /* o que vira link no texto da matéria — e, sobretudo, o que NÃO vira:
       inventar endereço de norma na página que se vende por citar a fonte é o
       pior defeito possível ali */
    "lib/normas.ts",
  ];
  const cfg = path.join(RAIZ, "tsconfig.testes.json");
  fs.writeFileSync(cfg, JSON.stringify({
    compilerOptions: {
      outDir: TMP, module: "esnext", target: "es2020",
      moduleResolution: "bundler", skipLibCheck: true, strict: true,
      esModuleInterop: true, baseUrl: ".", paths: { "@/*": ["./*"] },
      lib: ["dom", "esnext"], noEmit: false,
    },
    files: ARQUIVOS,
  }, null, 2));
  try {
    execSync(`npx tsc -p tsconfig.testes.json`, { cwd: RAIZ, stdio: "pipe" });
  } finally {
    fs.rmSync(cfg, { force: true });
  }
  /* o compilador não escreve a extensão nos imports; o Node ESM exige.
     A varredura é RECURSIVA e aceita subpasta desde que `lib/mailer/templates`
     entrou na lista: com a versão antiga, `from "./mailer/templates"` ficava
     sem `.js` e a suíte inteira morria com ERR_MODULE_NOT_FOUND — falha que
     parece "teste quebrado" e é só extensão faltando. */
  const arrumarImports = (dir) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) { arrumarImports(p); continue; }
      if (!e.name.endsWith(".js")) continue;
      fs.writeFileSync(
        p,
        fs.readFileSync(p, "utf8").replace(/from "(\.\.?\/[A-Za-z0-9_\-/]+)"/g,
          (m, alvo) => (alvo.endsWith(".js") ? m : `from "${alvo}.js"`))
      );
    }
  };
  arrumarImports(TMP);
  fs.writeFileSync(path.join(TMP, "package.json"), '{"type":"module"}');
  ok("compila sem erro", true);
} catch (e) {
  ok("compila sem erro", false, String(e.stdout ?? e).slice(0, 400));
  fim();
}

const motor = await import(path.join(TMP, "motor.js"));
const laudo = await import(path.join(TMP, "laudo.js"));
const triagem = await import(path.join(TMP, "triagem.js"));
const csvlib = await import(path.join(TMP, "csv.js"));
const coleta = await import(path.join(TMP, "coleta.js"));
/* a regra de "o que o clique faz e onde ele cai" vive em lib/cockpit.ts desde
   08/08/2026 — antes era ternário escrito na tela e um mapa morto que dizia o
   contrário */
const cockLib = await import(path.join(TMP, "cockpit.js"));

/* ============================================ 1. SUÍTES DE FUNÇÃO PURA == */
secao("Suítes de função pura");

/**
 * A LISTA VEM DO DISCO, e isso é a correção de um susto real.
 *
 * Esta linha era um array escrito à mão. Duas suítes novas (assinatura e
 * negócio) foram criadas, o array foi editado, e uma edição posterior o
 * restaurou — as duas sumiram da execução sem NENHUM sinal: o executor
 * continuou verde, só com 9 asserções a menos num total de 170. Teste que
 * some em silêncio é pior que teste que não existe, porque a confiança fica.
 *
 * Lendo a pasta, criar o arquivo já basta para ele rodar. E se algum dia uma
 * suíte precisar ficar de fora, isso vira uma decisão escrita aqui — não um
 * esquecimento.
 */
const SUITES = fs
  .readdirSync(path.join(RAIZ, "testes"))
  .filter((f) => f.endsWith(".test.mjs"))
  .map((f) => f.replace(/\.test\.mjs$/, ""))
  .sort();

ok(`${SUITES.length} suítes encontradas na pasta`, SUITES.length > 0, SUITES);

for (const suite of SUITES) {
  const arq = path.join(RAIZ, "testes", `${suite}.test.mjs`);
  fs.copyFileSync(arq, path.join(TMP, `${suite}.test.mjs`));
  const r = spawnSync("node", [`${suite}.test.mjs`], { cwd: TMP, encoding: "utf8" });
  const saida = (r.stdout || "") + (r.stderr || "");
  const total = (saida.match(/^ok:/gm) || []).length;
  ok(`suíte ${suite} (${total} asserções)`, r.status === 0,
     r.status === 0 ? undefined : (saida.split("\n").filter((l) => l.startsWith("FALHOU")).slice(0, 5).length
       ? saida.split("\n").filter((l) => l.startsWith("FALHOU")).slice(0, 5)
       : saida.split("\n").filter(Boolean).slice(-6)));
}

/* ================================================ 1b. AUDITORIA DE UX ==== */
secao("Auditoria de UX (percepção, não estética)");
{
  // Dois botões seguidos foram reportados como "não funciona" e nenhum estava
  // quebrado: o efeito nascia fora da tela. Nada aqui pegava isso, porque o
  // código estava certo. Esta auditoria procura essa família — causa e efeito,
  // não beleza.
  const r = spawnSync("node", [path.join(RAIZ, "testes", "auditar-ux.mjs")], { encoding: "utf8" });
  const saida = (r.stdout || "") + (r.stderr || "");
  const regras = (saida.match(/^ok: /gm) || []).length;
  ok(`auditoria de UX (${regras} regras limpas)`, r.status === 0,
     r.status === 0 ? undefined : saida.split("\n").filter((l) => l.trim().startsWith("components/") || l.trim().startsWith("app/")).slice(0, 8));
}

/* ================================== 1b1. TEXTO QUE VOLTA A CRESCER ==== */
secao("Auditoria de texto (as telas de trabalho, não os documentos)");
{
  /**
   * A limpeza de 08/08/2026 cortou centenas de palavras das telas onde o
   * contador trabalha todo dia. Sem limite escrito elas voltam — e voltam com
   * boas intenções, uma frase por correção. Este auditor é o limite escrito:
   * parágrafo na tela de trabalho, frase repetida no mesmo arquivo e rótulo de
   * botão que não cabe numa promessa.
   */
  const r = spawnSync("node", [path.join(RAIZ, "testes", "auditar-texto.mjs")], { encoding: "utf8" });
  const saida = (r.stdout || "") + (r.stderr || "");
  const regras = (saida.match(/^ok: /gm) || []).length;
  ok(`auditoria de texto (${regras} regras limpas)`, r.status === 0,
     r.status === 0 ? undefined : saida.split("\n").filter((l) => l.trim().startsWith("components/")).slice(0, 8));
}

/* ============================================ 1b2. SCHEMA SEM LASTRO ==== */
secao("Auditoria de schema (colunas que ninguém garante que existem)");
{
  /**
   * O cliente do Supabase não é tipado aqui: `select()` recebe uma string, e
   * pedir uma coluna inexistente compila, passa nos testes de função pura e só
   * quebra em produção. Aconteceu com `termos.tenant_id`, dentro da rota de
   * ASSINATURA — o fecho da esteira derrubado por um aviso acessório.
   */
  const r = spawnSync("node", [path.join(RAIZ, "testes", "auditar-schema.mjs")], { encoding: "utf8" });
  const saida = (r.stdout || "") + (r.stderr || "");
  const tabelas = (saida.match(/^ok: /gm) || []).length;
  ok(`auditoria de schema (${tabelas} tabelas com proveniência)`, r.status === 0,
     r.status === 0 ? undefined : saida.split("\n").filter((l) => l.startsWith("SUSPEITA")).slice(0, 6));
}

/* ==================================== 1b3. UPSERT QUE O BANCO RECUSA ==== */
secao("Auditoria de upsert (o onConflict que o Postgres não consegue inferir)");
{
  /**
   * A central de faturas ficou VAZIA por dias com tudo aparentemente
   * funcionando: cobrança gerada, e-mail enviado, webhook recebido, 200 em
   * todo mundo. O culpado era um `where` numa linha de índice — `ON CONFLICT
   * (asaas_id)` não infere índice PARCIAL, e o supabase-js devolve o erro em
   * vez de lançar, então ninguém lia.
   *
   * Três upserts estavam quebrados pelo mesmo motivo (faturas, curso_leads,
   * convites) e nenhum teste alcançava: compilam, passam no lint, sobem, e só
   * o banco reclama — para ninguém.
   */
  const r = spawnSync("node", [path.join(RAIZ, "testes", "auditar-upsert.mjs")], { encoding: "utf8" });
  const saida = (r.stdout || "") + (r.stderr || "");
  const conferidos = (saida.match(/^ok: /gm) || []).length;
  ok(`auditoria de upsert (${conferidos} conferidos)`, r.status === 0,
     r.status === 0 ? undefined : saida.split("\n").filter((l) => l.startsWith("QUEBRADO")).slice(0, 8));
}

/* ==================== 1b5. UM TEXTO, UM DONO =========================== */
secao("Cópias silenciosas do texto do documento");
{
  /**
   * As cláusulas de ciência do termo existiam em DOIS arquivos; quando o
   * cadeado do art. 41 § 5º entrou, ele entrou numa TERCEIRA cópia nova. O
   * termo que o cliente abre pelo link de assinatura continuou mostrando a
   * lista antiga — e é essa a lista que vira hash, que é a que ele assina.
   *
   * Nada quebrou: compilou, buildou, os testes passaram. O sinal só aparece
   * comparando duas telas, e ninguém compara duas telas toda semana.
   */
  const r = spawnSync("node", [path.join(RAIZ, "ferramentas", "auditar-copias.mjs"), "--autoteste"], { encoding: "utf8" });
  const saida = (r.stdout || "") + (r.stderr || "");
  const regras = (saida.match(/^ok: /gm) || []).length;
  ok(`um texto, um dono (${regras} conferências, com sabotagem)`, r.status === 0,
     r.status === 0 ? undefined : saida.split("\n").filter((l) => /FALHOU|CÓPIA/.test(l)).slice(0, 8));
}

/* ======================== 1b4. A FRONTEIRA SERVIDOR ↔ CLIENTE =========== */
secao("Fronteira servidor ↔ cliente (o proxy que compila e cai no ar)");
{
  /**
   * A tela de Contas devolveu "Application error: a server-side exception has
   * occurred" em produção com TUDO verde aqui: TypeScript aprovou, `next build`
   * passou, 254 verificações passaram. `comoMetrica()` morava dentro de um
   * módulo `"use client"` e era chamada por um Server Component — do lado do
   * servidor, todo export de módulo cliente é um PROXY, e chamá-lo lança.
   *
   * Nenhum teste de função pura alcança isso: em Node a função é uma função. É
   * uma regra do framework, e por isso precisa de um auditor próprio.
   *
   * Rodamos com `--autoteste`: além de varrer o código, ele reintroduz o bug
   * original e confere que a varredura o pega. Auditor que só sabe dizer "ok"
   * não é trava.
   */
  const r = spawnSync("node", [path.join(RAIZ, "ferramentas", "auditar-fronteira.mjs"), "--autoteste"], { encoding: "utf8" });
  const saida = (r.stdout || "") + (r.stderr || "");
  const regras = (saida.match(/^ok: /gm) || []).length;
  ok(`fronteira servidor ↔ cliente (${regras} conferências, com sabotagem)`, r.status === 0,
     r.status === 0 ? undefined : saida.split("\n").filter((l) => /FALHOU|FRONTEIRA/.test(l)).slice(0, 8));
}

/* ================= 1b5. AS DUAS METADES DO SITE, UM MENU SÓ ============= */
secao("Casca pública (o menu que existe em dois lugares)");
{
  /**
   * O site é HTML portado com o cabeçalho embutido em cada `const HTML`; o
   * app é Tailwind, com o cabeçalho em `CascaPublica`. São DUAS cópias do
   * mesmo menu, e nada aqui olhava para as duas ao mesmo tempo.
   *
   * Foi assim que /reforma e /curso foram para o ar com um menu diferente do
   * de /precos e /faq: marca de outro tamanho, botões de outra forma. Quem
   * navegava entre as metades tinha a impressão de ter saído do site.
   * Compilou, buildou, 327 verificações passaram.
   */
  const r = spawnSync("node", [path.join(RAIZ, "ferramentas", "auditar-casca.mjs"), "--autoteste"], { encoding: "utf8" });
  const saida = (r.stdout || "") + (r.stderr || "");
  const regras = (saida.match(/^ok: /gm) || []).length;
  ok(`um menu só nas duas metades (${regras} conferências, com sabotagem)`, r.status === 0,
     r.status === 0 ? undefined : saida.split("\n").filter((l) => /FALHOU|menu/.test(l)).slice(0, 8));
}

/* ============== 1b4. A PROMESSA DE SEGURANÇA TEM QUE TER LASTRO ========= */
secao("Segurança do dado — o que a tela promete no momento da fricção");
{
  /**
   * O momento mais caro do produto é pedir a CARTEIRA do contador: a lista de
   * clientes, o ativo do escritório, a alguém que conheceu o sistema há dez
   * minutos. Quem hesita ali não escreve perguntando — fecha a aba.
   *
   * Por isso a resposta foi para dentro da tarefa. E por isso ela precisa de
   * trava: promessa de segurança que descola do documento publicado é pior do
   * que promessa nenhuma, porque vira desmentido no dia em que alguém confere.
   * Cada afirmação do bloco tem que continuar existindo no documento.
   */
  const comp = fs.readFileSync(path.join(RAIZ, "components/SegurancaDoDado.tsx"), "utf8");
  const legal = fs.readFileSync(path.join(RAIZ, "lib/legal.json"), "utf8");
  const seg = JSON.parse(legal).documentos.find((d) => d.slug === "seguranca");
  const textoSeg = JSON.stringify(seg).toLowerCase();

  const AFIRMACOES = [
    ["separação no banco, não filtro de tela", "row level security"],
    ["não treina modelo com o conteúdo da conta", "treinar modelo"],
    ["nenhuma IA processa a carteira", "inteligência artificial"],
    ["o contador exporta quando quiser", "exporta"],
    ["tráfego em TLS", "tls"],
  ];
  for (const [nome, agulha] of AFIRMACOES) {
    ok(`a tela promete "${nome}" e o documento sustenta`, textoSeg.includes(agulha), agulha);
  }

  /**
   * O link tem que estar nas DUAS versões do bloco — a compacta (trilha) e a
   * inteira (tela de importar). Procurar no arquivo passava com o link
   * removido de uma delas, porque a outra ainda casava: o mesmo erro de
   * guarda que já apareceu três vezes nesta base.
   */
  const iComp = comp.indexOf("if (compacto)");
  const variante = { compacta: comp.slice(iComp, comp.indexOf("return (", comp.indexOf("}", iComp))), inteira: comp.slice(comp.lastIndexOf("return (")) };
  for (const [nome, trecho] of Object.entries(variante)) {
    ok(`a versão ${nome} do bloco linka Segurança e Privacidade`,
       /href="\/seguranca"/.test(trecho) && /href="\/privacidade"/.test(trecho),
       trecho.replace(/\s+/g, " ").slice(0, 100));
  }

  /* o pedido encolheu: uma empresa antes da carteira inteira */
  const trilha = fs.readFileSync(path.join(RAIZ, "components/Trilha.tsx"), "utf8");
  ok("a trilha pede UMA empresa antes da carteira inteira",
     /Comece por uma empresa/.test(trilha) && !/titulo: "Suba a carteira"/.test(trilha));
  ok("e mostra a segurança no passo em que a carteira é pedida",
     /SegurancaDoDado/.test(trilha));

  const imp = fs.readFileSync(path.join(RAIZ, "app/painel/importar/page.tsx"), "utf8");
  ok("a tela de importar mostra o bloco na PRIMEIRA vez",
     /jaTem === 0 &&[\s\S]{0,80}<SegurancaDoDado/.test(imp));
  /* quem já tem carteira já decidiu: repetir a conversa vira ruído, e ruído
     gasta a credibilidade que o texto deveria construir. A checagem é simples
     de propósito: UMA aparição, e ela dentro da guarda. */
  const semGuarda = imp.replace(/\{jaTem === 0 && \([\s\S]*?\n      \)\}/, "");
  ok("...e NÃO repete para quem já tem carteira",
     (imp.match(/<SegurancaDoDado/g) || []).length === 1 && !/<SegurancaDoDado/.test(semGuarda),
     `${(imp.match(/<SegurancaDoDado/g) || []).length} aparições · fora da guarda: ${/<SegurancaDoDado/.test(semGuarda)}`);
}

/* ============================ 1b2. LER POR UMA PORTA, NAVEGAR POR OUTRA == */
secao("Painel da plataforma — o link que a RLS derruba");
{
  /**
   * O CASO REAL, 05/08/2026: abrir um laudo de uma conta gratuita não funcionava.
   *
   * A tela de registros por conta lê por `plataforma_conta()`, que é
   * `security definer` e enxerga o banco inteiro — então o laudo de QUALQUER
   * escritório aparece na lista. O link ia para `/doc/laudo/[id]`, que lê
   * `laudos` com o cliente da SESSÃO, e a RLS de `laudos` é
   * `tenant_id = tenant_atual()`. Nenhuma linha volta, `notFound()`, 404.
   *
   * O resultado é a pior forma dessa falha: a tela mostra que o documento
   * existe e se recusa a abri-lo. Não quebra build, não quebra teste de função
   * pura, e só aparece quando alguém clica na conta de outra pessoa — o que,
   * num painel de dono de plataforma, pode demorar semanas.
   *
   * A REGRA: tela que lê por função security definer não navega para página
   * que lê pela sessão. Ou passa pela rota que confere e registra, ou vai para
   * o endereço público por token.
   */
  const RLS_DA_SESSAO = ["/doc/laudo/", "/doc/termo/", "/doc/comparativo/"];
  const telas = [];
  (function anda(d) {
    for (const n of fs.readdirSync(d)) {
      const p = path.join(d, n);
      if (fs.statSync(p).isDirectory()) anda(p);
      else if (/\.tsx?$/.test(n)) telas.push(p);
    }
  })(path.join(RAIZ, "app/painel/negocio"));

  /* comentário que EXPLICA a armadilha não é a armadilha — e proibir a
     explicação seria trocar a regra pelo silêncio sobre ela */
  const semComentario = (s) => s.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");

  const infratores = [];
  for (const p of telas) {
    const src = semComentario(fs.readFileSync(p, "utf8"));
    for (const rota of RLS_DA_SESSAO) {
      if (src.includes(rota)) infratores.push(`${path.relative(RAIZ, p)} → ${rota}`);
    }
  }
  ok("o painel da plataforma não linka para página protegida por RLS de sessão",
     infratores.length === 0,
     infratores.join(" · ") + " — use /painel/negocio/registros/abrir, que confere e registra");

  /* e a rota que abre precisa CONFERIR e REGISTRAR, não só redirecionar:
     atalho de suporte sem rastro é o começo de todo acesso que ninguém explica */
  const abrir = path.join(RAIZ, "app/painel/negocio/registros/abrir/route.ts");
  const src = fs.existsSync(abrir) ? fs.readFileSync(abrir, "utf8") : "";
  ok("a rota de abrir documento existe e passa pela função que registra o acesso",
     src.includes("plataforma_documento_token"),
     src === "" ? "rota não encontrada" : "não chama plataforma_documento_token");
  ok("...e não usa o cliente admin para furar a RLS por conta própria",
     src !== "" && !src.includes("createAdminClient"),
     "importa createAdminClient — o acesso deixaria de passar pela conferência do banco");

  const mig = fs.readFileSync(path.join(RAIZ, "supabase/migrations/0053_abrir_documento_da_conta.sql"), "utf8");
  ok("...e a função confere e_plataforma() antes de devolver o token",
     mig.includes("e_plataforma()") && mig.includes("acessos_plataforma"),
     "a migration não confere quem pede ou não registra o acesso");
}

/* ======================================= 1c. O QUE O CLIENTE ALCANÇA ==== */
secao("Endereços públicos — o que chega ao cliente sem login");
{
  /**
   * O cliente do contador NÃO TEM CONTA e nunca vai ter — e no caso do estudo
   * de abertura ele nem cliente é ainda. Seis endereços
   * existem para ele, e todos dependem de continuar fora da guarda do
   * middleware. Proteger um deles por engano não quebra build nem teste de
   * função pura: quebra em produção, como um cliente batendo em tela de login
   * para ler o laudo que pagou — e o contador só descobre quando reclamam.
   */
  const PUBLICAS = ["assinar", "coleta", "laudo", "comparativo", "termo", "abertura"];
  const mw = fs.readFileSync(path.join(RAIZ, "middleware.ts"), "utf8");
  const guarda = mw.match(/path\.startsWith\("([^"]+)"\)/g) || [];
  const prefixos = guarda.map((g) => g.match(/"([^"]+)"/)[1]);

  for (const rota of PUBLICAS) {
    const existe = fs.existsSync(path.join(RAIZ, "app", rota, "[token]", "page.tsx"));
    const protegida = prefixos.some((p) => `/${rota}`.startsWith(p));
    ok(`/${rota}/[token] existe e é pública`, existe && !protegida,
       !existe ? "página não encontrada" : `bloqueada pelo middleware (${prefixos.join(", ")})`);
  }

  /**
   * E a página pública NÃO pode ler com a sessão: `createClient` de
   * supabase-server devolve o cliente do usuário, que não existe aqui. Uma
   * página assim compila, sobe, e devolve 404 para todo cliente.
   */
  for (const rota of PUBLICAS) {
    const arq = path.join(RAIZ, "app", rota, "[token]", "page.tsx");
    if (!fs.existsSync(arq)) continue;
    const src = fs.readFileSync(arq, "utf8");
    ok(`/${rota}/[token] lê por token, não por sessão`,
       src.includes("createAdminClient") && !/from "@\/lib\/supabase-server"/.test(src),
       src.includes("supabase-server") ? "importa o cliente de sessão" : "não usa createAdminClient");
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════
   * O FIO DO TERMO — a peça pronta que não chegava ao papel.
   * ═══════════════════════════════════════════════════════════════════════
   *
   * O CASO REAL, 05/08/2026. `components/FolhaTermo.tsx` ganhou os campos
   * `recomendacao`, `pontos`, `tipo_decisao` e `motivo_divergencia`. As funções
   * que os produzem foram escritas e testadas — 60 asserções passando. E
   * NENHUMA das três páginas passava as props; a rota nunca gravava as colunas.
   *
   * Compilava, buildava, a suíte inteira ficava verde. Deploy mostraria só a
   * lista de ciência crescendo de 4 para 7 itens, e o resto — a recomendação,
   * os pontos, a divergência — invisível, com todo o código no lugar.
   *
   * Teste de função pura não pega isso: a função está certa, ninguém a chama.
   * O que pega é olhar o FIO — quem produz, quem grava, quem imprime.
   */
  {
    const FIO = [
      ["app/doc/termo/[id]/page.tsx", ["recomendacao=", "pontos=", "tipo_decisao=", "laudo_url=", "clausulas="],
       "o dossiê do contador"],
      ["app/termo/[token]/page.tsx", ["recomendacao=", "pontos=", "tipo_decisao=", "laudo_url=", "clausulas="],
       "a via do cliente"],
      ["app/assinar/[token]/page.tsx", ["recomendacao=", "pontos=", "tipoDecisao=", "parte.clausulas"],
       "a tela onde ele assina"],
      ["app/api/termo/route.ts", ["recomendacao:", "blocoDoTermo", "hash_proposta"],
       "a rota que emite"],
      ["app/api/termo/lote/route.ts", ["recomendacao:", "blocoDoTermo", "hash_proposta"],
       "a rota de lote"],
      /* o guarda inteiro, não o import: apagar a chamada e deixar o import é
         exatamente o que um refactor distraído faz */
      ["app/api/assinar/route.ts",
       ["ehTipoDecisao(corpo.tipo_decisao)", "validarDecisao({", "if (!valida.ok)", "resolverDecisao(",
        "hash_documento: hashDocumento"],
       "a rota que assina"],
    ];
    for (const [arq, exigidos, oque] of FIO) {
      const src = fs.existsSync(path.join(RAIZ, arq)) ? fs.readFileSync(path.join(RAIZ, arq), "utf8") : "";
      const faltando = exigidos.filter((e) => !src.includes(e));
      ok(`${oque} passa a recomendação adiante`, src !== "" && faltando.length === 0,
         src === "" ? "arquivo não encontrado" : `faltando: ${faltando.join(", ")}`);
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * O FIO DO RADAR — o campo que o cockpit jogava fora.
     * ═══════════════════════════════════════════════════════════════════════
     *
     * O CASO REAL, 06/08/2026. O primeiro item de radar com critério por
     * ANEXO foi publicado. A função `radar_alcance()` do banco respondeu
     * "39 empresas", a rota de aviso mandou cinco e-mails dizendo
     * "39 clientes seus" — e o cockpit mostrou NADA.
     *
     * Motivo: `empresasRadar` era montado a partir de `linhas`, e `Linha`
     * (lib/cockpit) não carrega anexo. O mapeamento escrevia `anexo: null`, e
     * `afeta()` — corretamente — descarta empresa sem anexo quando o critério
     * pede anexo.
     *
     * `afeta()` estava certa. Os testes dela passavam. O erro morava no
     * caminho até ela, e é por isso que só um teste de FIO o pega: o defeito
     * não é o que a função faz, é o que chega nela.
     *
     * A regra que fica: quem monta EmpresaRadar tem de ler a tabela de
     * empresas. `anexo: null` escrito à mão é sempre um campo perdido.
     */
    {
      const MONTAM_RADAR = [
        ["app/painel/page.tsx", "o cockpit"],
        ["app/api/digest/route.ts", "o digest mensal"],
        ["app/api/radar/avisar/route.ts", "a rota de aviso"],
      ];
      for (const [arq, oque] of MONTAM_RADAR) {
        const src = fs.existsSync(path.join(RAIZ, arq)) ? fs.readFileSync(path.join(RAIZ, arq), "utf8") : "";
        ok(`${oque} não zera o anexo ao montar o radar`,
           src !== "" && !/anexo:\s*null\s*,/.test(src),
           src === "" ? "arquivo não encontrado"
                      : "achei `anexo: null` — o critério por anexo não vai alcançar ninguém");
        ok(`${oque} lê o anexo da carteira`,
           src !== "" && /anexo:\s*(\(?e(\s|\)|\.)|e\.anexo)/.test(src),
           src === "" ? "arquivo não encontrado" : "não achei o anexo vindo de `empresas`");
      }
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * O QUE ENTRA NO COCKPIT — e o que sai dele quando é lido.
     * ═══════════════════════════════════════════════════════════════════════
     *
     * DOIS DEFEITOS RELATADOS EM 06/08/2026, do mesmo tipo: a intenção estava
     * escrita e o código não fazia.
     *
     *   1. "marco como lido e não some". A regra era `if (lidos.has(id) &&
     *      avisos.length >= 1) continue` — o primeiro item lido continuava na
     *      tela quando era o único. Botão que não muda nada ensina a não
     *      confiar na interface.
     *
     *   2. o filtro `no_cockpit` existia só no comentário. Publicação marcada
     *      como NOTÍCIA — que por definição não deve interromper — entrava no
     *      topo da fila de trabalho do mesmo jeito.
     *
     * As duas regressões são invisíveis: nada quebra, a tela só fica errada.
     * Por isso viram asserção de texto — feia, e a única que pega este caso.
     */
    {
      const arq = path.join(RAIZ, "app/painel/page.tsx");
      const src = fs.existsSync(arq) ? fs.readFileSync(arq, "utf8") : "";

      ok("o cockpit só mostra ALERTA, não notícia",
         /\.eq\(\s*["']no_cockpit["']\s*,\s*true\s*\)/.test(src),
         "faltou `.eq(\"no_cockpit\", true)` na busca do radar — notícia vai interromper a fila");

      ok("item lido some do cockpit, sem exceção",
         /if\s*\(\s*lidos\.has\(item\.id\)\s*\)\s*continue/.test(src),
         "não achei o corte seco do item lido");

      ok("e o corte não voltou a ter exceção por contagem",
         !/lidos\.has\(item\.id\)\s*&&/.test(src),
         "achei `lidos.has(item.id) &&` — a exceção que fazia o aviso lido ficar na tela");
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * A EMISSÃO NÃO DECIDE — a decisão é de quem assina.
     * ═══════════════════════════════════════════════════════════════════════
     *
     * Até 05/08/2026 o contador escolhia seguir/divergir/adiar na hora de
     * emitir, e o termo chegava ao cliente dizendo "a empresa decide optar".
     * A empresa assinava embaixo de uma decisão que nunca declarou — o papel
     * voltava a não distinguir quem decidiu o quê.
     *
     * O sinal mais confiável de recaída é o HASH: se a emissão volta a calcular
     * `hash_documento`, é porque voltou a achar que conhece a decisão. Um hash
     * feito antes de a decisão existir não cobre a decisão.
     */
    {
      const emissao = ["app/api/termo/route.ts", "app/api/termo/lote/route.ts"];
      for (const arq of emissao) {
        const src = fs.readFileSync(path.join(RAIZ, arq), "utf8").replace(/\/\*[\s\S]*?\*\//g, "");
        ok(`${arq.split("/").slice(2).join("/")} não calcula o hash do documento na emissão`,
           !/hash_documento:\s*hash\b/.test(src) && !/conteudoCanonico\(/.test(src),
           "voltou a selar o documento antes de a decisão existir");
        ok(`${arq.split("/").slice(2).join("/")} grava a decisão em branco`,
           /p_decisao:\s*"sem_decisao"/.test(src),
           "está gravando uma decisão que a empresa não declarou");
      }
      const assina = fs.readFileSync(path.join(RAIZ, "app/api/assinar/route.ts"), "utf8");
      ok("a rota de assinatura carimba a evidência com o hash NOVO",
         /montarEvidencia\([\s\S]{0,200}hash_documento:\s*hashDocumento/.test(assina) &&
           /carimbar\(hashDocumento/.test(assina),
         "a evidência ou o carimbo ainda usam o hash da emissão, que não cobre a decisão");
    }

    /**
     * A FOLHA IMPRIME A LISTA CONGELADA, não a constante viva.
     *
     * Quando a ciência cresceu de 4 para 7 itens em 05/08/2026, os 21 termos já
     * emitidos passaram a ser EXIBIDOS com 7 cláusulas — e o hash deles cobre 4.
     * Dois já estavam assinados: o papel passou a dizer que o signatário deu
     * ciência do cadeado do art. 41 § 5º, e ele não deu. O documento passou a
     * dizer MAIS do que foi aceito, que é a pior direção do erro.
     */
    {
      const folha = fs.readFileSync(path.join(RAIZ, "components/FolhaTermo.tsx"), "utf8")
        .replace(/\/\*[\s\S]*?\*\//g, "");
      /* termo pendente não pode imprimir escolha que ninguém fez */
      ok("a folha não afirma decisão em termo emitido e não assinado",
         /!tipo_decisao\s*&&\s*!assinado/.test(folha) && /AGUARDANDO_DECISAO/.test(folha),
         "as caixinhas voltam marcadas antes de a empresa decidir");
      ok("a folha imprime a lista de ciência CONGELADA, não a constante viva",
         /\(\s*clausulas\s*\?\?\s*CIENCIA_DOS_EFEITOS\s*\)/.test(folha),
         "usa CIENCIA_DOS_EFEITOS direto — termo antigo passa a exibir cláusula que o hash dele não cobre");
    }

    /* e as três superfícies leem o snapshot pela MESMA função — cada uma lendo
       do seu jeito é como o cliente acaba lendo uma coisa e assinando outra */
    for (const arq of ["app/doc/termo/[id]/page.tsx", "app/termo/[token]/page.tsx", "app/assinar/[token]/page.tsx"]) {
      const src = fs.readFileSync(path.join(RAIZ, arq), "utf8");
      ok(`${arq.split("/").slice(0, 3).join("/")} lê o snapshot pela função comum`,
         src.includes("decisaoDoSnapshot"), "não importa decisaoDoSnapshot de lib/termo");
    }
  }

  /**
   * O BOTÃO DO E-MAIL PRECISA ABRIR O DOCUMENTO.
   *
   * Bug real: o comprovante de assinatura dizia "guardar uma cópia do termo" e
   * apontava para /assinar/[token], que depois de assinado mostra um aviso e o
   * hash. O cliente ficava sem via nenhuma — e isso não aparece em build, em
   * tipo nem em teste de função: aparece na hora em que alguém contesta a
   * decisão e a única via imprimível está atrás do login da outra parte.
   */
  {
    const api = fs.readFileSync(path.join(RAIZ, "app/api/assinar/route.ts"), "utf8");
    const linha = (api.match(/const linkTermo = [^\n]+/) || [""])[0];
    ok("o comprovante do cliente linka o termo, não a página de assinatura",
       linha.includes("/termo/") && !linha.includes("/assinar/"), linha || "linha não encontrada");
  }

  /**
   * E O VÍDEO DA AULA aceita o link que o YouTube entrega no botão
   * compartilhar. `src={aula.video}` cru obrigava a colar a URL de embed —
   * quem colasse youtu.be publicava uma aula com o player recusando carregar.
   */
  {
    const aula = fs.readFileSync(path.join(RAIZ, "app/curso/[slug]/page.tsx"), "utf8");
    ok("a aula normaliza a URL do vídeo antes do iframe",
       aula.includes("urlDeEmbed") && !/src=\{aula\.video\}/.test(aula),
       /src=\{aula\.video\}/.test(aula) ? "iframe recebe a URL crua" : "não chama urlDeEmbed");
  }
}


/* ================================== 1d. OS DOCUMENTOS IMPRIMEM IGUAL ==== */
secao("Impressão — o PDF que chega ao cliente");
{
  /**
   * O CSS de impressão estava copiado em quatro folhas e já tinha divergido:
   * laudo 18mm, termo 18/16, relatório 22. Documento com margem diferente do
   * termo da mesma empresa parece montado em lugares diferentes — e é
   * exatamente o que o white-label promete que não acontece. Nada disso
   * quebra build: só aparece no papel.
   */
  const FOLHAS = [
    "components/LaudoFolha.tsx",
    "components/ComparativoFolha.tsx",
    "components/FolhaTermo.tsx",
    "app/doc/relatorio/page.tsx",
  ];
  for (const f of FOLHAS) {
    const src = fs.readFileSync(path.join(RAIZ, f), "utf8");
    const proprias = (src.match(/@page\s*\{/g) || []).length;
    ok(`${f} usa o CSS de impressão comum`,
       src.includes("CSS_IMPRESSAO") && proprias === 0,
       proprias > 0 ? "declara @page por conta própria" : "não importa CSS_IMPRESSAO");
  }

  const comum = fs.readFileSync(path.join(RAIZ, "lib/impressao.ts"), "utf8");
  ok("o CSS comum apaga o fundo cinza do app no papel",
     /html,\s*body\s*\{\s*background:\s*#fff/.test(comum));

  /**
   * A MARGEM NÃO PODE DEPENDER SÓ DO `@page`.
   *
   * Bug real: PDF com o texto encostado na borda. A opção "Margens" da janela
   * de impressão é do usuário e sobrescreve o `@page` — quem deixou em
   * "Nenhuma" uma vez imprime assim para sempre. Com a folha zerando o
   * próprio padding, não sobrava nada entre o texto e o corte.
   *
   * Este teste existe porque `padding: 0 !important` na impressão PARECE
   * limpeza correta: a folha imita papel na tela, então zerar soa certo. É
   * exatamente o tipo de "arrumação" que volta.
   */
  // a partir do CSS de verdade, não do comentário que o explica
  const css = comum.slice(comum.indexOf("export const CSS_IMPRESSAO"));
  const bloco = css.slice(css.indexOf(".sheet {"), css.indexOf("tr, li"));
  ok("a folha guarda a própria margem na impressão (o usuário pode zerar a do papel)",
     /padding:\s*\d+mm/.test(bloco) && !/padding:\s*0\s*!important/.test(bloco),
     bloco.replace(/\s+/g, " ").slice(0, 120));
  ok("e o @page também declara margem, para quando o navegador respeitar",
     /@page\s*\{\s*margin:\s*\d+mm/.test(comum));
  ok("e impede a linha de tabela partida entre páginas",
     /tr,\s*li\s*\{\s*page-break-inside:\s*avoid/.test(comum));

  /**
   * A margem do `@page` não apaga o cabeçalho do navegador — a URL e a data
   * no pé de cada página saem assim mesmo, num laudo com a marca do
   * escritório. Só a caixinha do usuário apaga, e ninguém desmarca uma opção
   * que não sabe que existe.
   */
  const botao = fs.readFileSync(path.join(RAIZ, "components/BotaoImprimir.tsx"), "utf8");
  ok("o botão de PDF ensina a desmarcar cabeçalhos e rodapés",
     /Cabeçalhos e rodapés/.test(botao) && /Salvar como PDF/.test(botao));
  ok("e a avisar sobre a opção de margens, que é a que corta o texto",
     /Margens/.test(botao));
}

/* =========================== 1e. TIRAR EMPRESA DA FILA TEM VOLTA ======== */
secao("Arquivar — a saída e o caminho de volta");
{
  /**
   * Arquivar sem tela de arquivadas é sumiço: a única tela que sabe
   * desarquivar é o dossiê, e o dossiê se abre a partir da fila — de onde a
   * empresa acabou de sair.
   */
  const dossie = fs.readFileSync(path.join(RAIZ, "app/api/dossie/route.ts"), "utf8");
  ok("o dossiê abre empresa arquivada (senão arquivar não tem volta)",
     !/\.is\("arquivada_em", null\)/.test(dossie) && /arquivada_em/.test(dossie));

  const fila = fs.readFileSync(path.join(RAIZ, "app/painel/page.tsx"), "utf8");
  ok("mas a FILA continua escondendo as arquivadas",
     /\.is\("arquivada_em", null\)/.test(fila));

  ok("existe a tela que lista as arquivadas",
     fs.existsSync(path.join(RAIZ, "app/painel/arquivadas/page.tsx")));

  const nav = fs.readFileSync(path.join(RAIZ, "lib/nav.ts"), "utf8");
  ok("e ela é alcançável pelo menu", /\/painel\/arquivadas/.test(nav));
}


/* ================================= 1f. O MENU NÃO PODE REGREDIR ========= */
secao("Menu — a estrutura que já foi desfeita sem querer");
{
  /**
   * Esta estrutura foi decidida, desfeita numa reorganização e redecidida.
   * Nada aqui quebra build: um item de menu que reaparece no lugar errado só
   * é percebido por quem usa o produto todo dia — e aí já foi ao ar.
   */
  const nav = fs.readFileSync(path.join(RAIZ, "lib/nav.ts"), "utf8");
  const bloco = (nome) => {
    const i = nav.indexOf(`export const ${nome}`);
    if (i < 0) return "";
    return nav.slice(i, nav.indexOf("];", i));
  };

  ok("Reforma e Curso andam juntos (o que a pessoa quer APRENDER)",
     /painel\/reforma/.test(bloco("ABAS_APRENDER")) && /"\/curso"/.test(bloco("ABAS_APRENDER")));
  ok("Ajuda e chamados andam juntos (o que ela quer RESOLVER)",
     /painel\/ajuda/.test(bloco("ABAS_AJUDA")) && /painel\/chamados/.test(bloco("ABAS_AJUDA")));
  ok("e as duas duplas não se misturam",
     !/painel\/reforma/.test(bloco("ABAS_AJUDA")) && !/painel\/chamados/.test(bloco("ABAS_APRENDER")));

  ok("o comparativo de regimes tem porta própria, fora da empresa",
     fs.existsSync(path.join(RAIZ, "app/painel/estudos/page.tsx")) &&
     /painel\/estudos/.test(bloco("ABAS_ESTUDOS")));
  ok("e divide a faixa com a abertura",
     /painel\/abertura/.test(bloco("ABAS_ESTUDOS")));

  /**
   * A área de plataforma é só do superadmin. Seis links dela no menu lateral
   * dobravam o menu de quem trabalha na carteira todo dia.
   */
  const plataforma = nav.slice(nav.indexOf("export const NAV_PLATAFORMA"), nav.indexOf("export const ABAS_ESCRITORIO"));
  const itensPlataforma = (plataforma.match(/href:/g) || []).length;
  ok("Plataforma é UM item de menu, com o resto dentro da página",
     itensPlataforma === 1, `${itensPlataforma} itens no menu`);

  const abasNegocio = fs.readFileSync(path.join(RAIZ, "components/NegocioAbas.tsx"), "utf8");
  ok("e a faixa de abas do Negócio não é uma segunda lista escrita à mão",
     abasNegocio.includes("ABAS_NEGOCIO") && !/const ABAS = \[/.test(abasNegocio));

  /* Planos é item próprio de menu; a faixa do escritório não pertence a ele */
  const planos = fs.readFileSync(path.join(RAIZ, "app/painel/planos/page.tsx"), "utf8");
  ok("a tela de Planos não carrega as abas de Configurações/Equipe/Indique",
     !/AbasEscritorio/.test(planos));
}


/* ============================ 1g. O CAMINHO DO DINHEIRO NÃO PODE CALAR == */
secao("Contratação — o clique que não fazia nada");
{
  /**
   * Bug real: "Assinar" não fazia NADA. Três defeitos empilhados —
   *   1. não mandávamos `cpfCnpj`, que o Asaas exige para criar cliente;
   *   2. o erro do Asaas era engolido num `catch` que devolvia null;
   *   3. a tela só tratava "tem link" e "Asaas desligado" — faltava o
   *      terceiro caso, Asaas LIGADO e sem link, que é onde o clique morria.
   *
   * Nada disso quebra build, e nenhum teste de função pura alcança. O que
   * protege é exigir que cada elo continue existindo.
   */
  const asaas = fs.readFileSync(path.join(RAIZ, "lib/asaas.ts"), "utf8");
  /* olhar só por "cpfCnpj" no arquivo casava com o NOME DO PARÂMETRO e passava
     mesmo com o campo fora do corpo do POST — o defeito exato que existia.
     A checagem tem que ser no corpo enviado ao endpoint de clientes. */
  const posCustomers = asaas.indexOf('`${base}/customers`');
  const corpoCliente = posCustomers < 0 ? "" : asaas.slice(posCustomers, posCustomers + 400);
  ok("a criação do cliente manda cpfCnpj NO CORPO do POST",
     /body:[\s\S]*cpfCnpj/.test(corpoCliente),
     corpoCliente.replace(/\s+/g, " ").slice(0, 140));
  ok("as chamadas mandam User-Agent (sem ele o Asaas responde 401)",
     /User-Agent/.test(asaas));
  ok("o erro do Asaas sobe em vez de virar null",
     /erro\?: string/.test(asaas) && !/\} catch \{\s*return \{ ativo: true \};/.test(asaas));

  const checkout = fs.readFileSync(path.join(RAIZ, "app/api/checkout/route.ts"), "utf8");
  ok("o checkout recusa antes de chamar o Asaas quando falta documento",
     /criticaDocumento/.test(checkout) && /falta_documento/.test(checkout));
  ok("e responde erro quando o Asaas está ligado e não devolveu link",
     /cobranca\.ativo && !cobranca\.checkout_url/.test(checkout));


  /**
   * O WEBHOOK PRECISA RESPONDER NOS DOIS CAMINHOS.
   *
   * Caso real (04/08/2026): a rota vive em `/api/asaas`, o painel do Asaas foi
   * configurado com `/api/webhooks/asaas` — o caminho mais natural de escrever.
   * Resultado: 404 em todo evento, penalização automática, fila suspensa. A
   * cobrança existia lá e não existia aqui: sem fatura, sem e-mail, sem acesso.
   *
   * Nada disso quebra build. O que protege é exigir que os dois endereços
   * continuem existindo — e que o segundo NÃO seja uma segunda implementação,
   * que divergiria na primeira correção.
   */
  const alias = path.join(RAIZ, "app/api/webhooks/asaas/route.ts");
  ok("o webhook também responde em /api/webhooks/asaas", fs.existsSync(alias));
  if (fs.existsSync(alias)) {
    const src = fs.readFileSync(alias, "utf8");
    ok("e o alias reexporta o mesmo handler, sem copiar a lógica",
       /export \{ POST \} from "@\/app\/api\/asaas\/route"/.test(src) && !/statusDoAsaas|upsert/.test(src));
  }

  /* webhook é entrega best-effort: tem que existir caminho para reconstruir */
  const asaasLib = fs.readFileSync(path.join(RAIZ, "lib/asaas.ts"), "utf8");
  ok("existe como reimportar as faturas que o webhook perdeu",
     /export async function importarFaturas/.test(asaasLib));
  ok("e a importação só aceita pagamento com externalReference nosso",
     /externalReference/.test(asaasLib.slice(asaasLib.indexOf("importarFaturas"))));

  /* a cobrança gerada não pode depender de webhook para chegar em alguém */
  const checkout2 = fs.readFileSync(path.join(RAIZ, "app/api/checkout/route.ts"), "utf8");
  ok("o link de pagamento sai por e-mail na hora da contratação",
     /htmlCobrancaGerada/.test(checkout2));


  /**
   * QUEM ESCREVE FATURA É O SERVIDOR — nunca a sessão do usuário.
   *
   * Bug real: o checkout gravava a fatura com o cliente da SESSÃO. A RLS de
   * `faturas` dá ao escritório apenas SELECT (de propósito: quem pudesse
   * escrever inseriria uma linha "paga" e liberaria acesso sem pagar). A
   * escrita era recusada, o supabase-js devolve `{error}` em vez de lançar, o
   * código ignorava — e o sintoma foi: o e-mail da cobrança saía e a fatura
   * não aparecia em lugar nenhum.
   */
  const mig39 = fs.readFileSync(path.join(RAIZ, "supabase/migrations/0039_faturas.sql"), "utf8");
  ok("a RLS de faturas dá só leitura ao escritório",
     /faturas_do_escritorio[\s\S]{0,120}for select/.test(mig39));

  const ck = fs.readFileSync(path.join(RAIZ, "app/api/checkout/route.ts"), "utf8");
  /* olhar uma janela em volta da chamada casava com o `createAdminClient` da
     linha vizinha e passava mesmo com a escrita feita pela sessão — que é o
     defeito exato que existia. A checagem é na CHAMADA. */
  ok("...e por isso o checkout grava a fatura com o cliente de serviço",
     /\(admin \?\? supabase\)\.from\("faturas"\)/.test(ck),
     (ck.match(/[\w.() ?]*\.from\("faturas"\)/) || ["não achei a chamada"])[0]);

  /**
   * O ERRO DA GRAVAÇÃO PRECISA CHEGAR NA TELA, não só no log.
   *
   * Enquanto a falha da fatura era um `console.error`, o bug do índice parcial
   * (0041) durou dias: a cobrança nascia, o e-mail saía, a linha não gravava, e
   * a única pista morava num log que ninguém abre. Log não é aviso.
   */
  ok("e o resultado da gravação volta na resposta do checkout",
     /fatura_registrada/.test(ck) && /fatura_erro/.test(ck));

  /* o terceiro estado da tela de planos: contratado e ainda não pago */
  const telaPlanos = fs.readFileSync(path.join(RAIZ, "app/painel/planos/page.tsx"), "utf8");
  ok("a tela de planos mostra a assinatura pendente de pagamento",
     /pendente/.test(telaPlanos) && /aguardando/i.test(telaPlanos));

  /**
   * E O ESTADO É POR PLANO, não global.
   *
   * Bug real: com uma pendência de mensal na mesa, contratar o ANUAL não mudava
   * o botão do cartão anual. A tela lia UMA pendência (`.limit(1)`) e comparava
   * com todos os cartões — o cartão certo perdia a corrida por acaso.
   */
  ok("e lê TODAS as pendentes, não a primeira que aparecer",
     !/\.eq\("status", "pendente"\)\s*\n?\s*\.limit\(1\)/.test(telaPlanos) &&
     /pendentes\.has\(p\.id\)/.test(telaPlanos),
     /limit\(1\)/.test(telaPlanos) ? "ainda usa limit(1)" : "não indexa por plano");

  /**
   * E A TELA RELÊ O BANCO DEPOIS DE CONTRATAR.
   *
   * Sem isto, contratar abria a aba do pagamento e deixava esta página
   * exatamente como estava: sem a fatura nova na lista e sem o cartão mudar de
   * estado. Do lado de quem clicou, indistinguível de "não funcionou".
   */
  ok("e recarrega o estado depois da contratação",
     /await carregar\(\)/.test(telaPlanos));

  /**
   * ═════════════════════════════════════════════════════════════════════════
   * UMA CONTA, UM PLANO — a ligação entre a regra e o mundo.
   *
   * A decisão em si é função pura e está coberta em `testes/assinatura.test.mjs`
   * (36 asserções, quebradas de propósito em quatro frentes). O que NENHUM
   * teste de função pura alcança é a fiação: a rota chamar a decisão, o webhook
   * encerrar as superadas, o boleto velho morrer no Asaas. Cada elo abaixo,
   * quando some, produz o mesmo sintoma da denúncia original — cobrança
   * duplicada e dois planos na mesma conta.
   * ═════════════════════════════════════════════════════════════════════════
   */
  ok("o checkout decide pela regra de plano único, não por conta própria",
     /decidirContratacao/.test(ck) && /encerrarAssinaturas/.test(ck));
  ok("e clicar de novo no mesmo plano devolve a cobrança existente",
     /reaproveitar/.test(ck) && /reaproveitada: true/.test(ck));

  const wh = fs.readFileSync(path.join(RAIZ, "app/api/asaas/route.ts"), "utf8");
  ok("a troca de plano só acontece quando o pagamento é confirmado",
     /decidirSucessao/.test(wh) && /encerrarAssinaturas/.test(wh));
  /* a ORDEM é o que impede a conta ficar sem plano nenhum com o dinheiro pago */
  ok("...e as antigas caem DEPOIS de a nova virar ativa",
     wh.indexOf('status: "ativa"') < wh.indexOf("await encerrarAssinaturas"),
     { ativa: wh.indexOf('status: "ativa"'), encerrar: wh.indexOf("await encerrarAssinaturas") });
  ok("os dias pagos que sobram entram no plano novo",
     /credito/.test(wh) && /validadeFinal\(/.test(wh));

  /**
   * O BOLETO ABANDONADO PRECISA MORRER NO ASAAS.
   *
   * Deixá-lo aberto é o pior dos dois mundos: o cliente pode pagar o plano que
   * largou, e o webhook — que não sabe de nada — ativa aquele por cima do que
   * ele acabou de comprar.
   */
  ok("existe como cancelar a cobrança no Asaas",
     /export async function cancelarCobranca/.test(asaas) && /method: "DELETE"/.test(asaas));
  const encerrar = fs.readFileSync(path.join(RAIZ, "lib/assinatura-server.ts"), "utf8");
  ok("e o encerramento usa isso antes de marcar a fatura",
     encerrar.indexOf("cancelarCobranca(") < encerrar.indexOf('status: "cancelado"'));
  ok("e fatura PAGA nunca é reescrita",
     /\.in\("status", \["pendente", "vencido"\]\)/.test(encerrar));

  /**
   * ═════════════════════════════════════════════════════════════════════════
   * AS MÉTRICAS DE RECEITA — o painel que mostrava R$ 0 com dinheiro na conta.
   *
   * `assinaturas.valor_centavos` era NULL em toda assinatura criada pelo
   * checkout, e o MRR lia só dele. As contas estão cobertas em
   * `testes/negocio.test.mjs`; aqui garantimos que a rota grava o valor e que a
   * tela do negócio mostra o caixa, que é a pergunta que faltava.
   * ═════════════════════════════════════════════════════════════════════════
   */
  /* procurar `valor_centavos: plano.preco_centavos` no arquivo inteiro casava
     com a chamada do Asaas e com o upsert da fatura, e passava mesmo com o
     campo FORA do insert da assinatura — que é onde o painel lê. A checagem
     tem que ser dentro do insert. */
  {
    const i = ck.indexOf('.from("assinaturas")\n    .insert(');
    const insert = i < 0 ? "" : ck.slice(i, i + 320);
    ok("o checkout grava o valor NO INSERT da assinatura (senão o MRR nasce zero)",
       /\.insert\(/.test(insert) && /valor_centavos:\s*plano\.preco_centavos/.test(insert),
       insert.replace(/\s+/g, " ").slice(0, 170) || "não achei o insert de assinaturas");
  }

  const telaNegocio = fs.readFileSync(path.join(RAIZ, "app/painel/negocio/page.tsx"), "utf8");
  ok("o painel separa receita recorrente (promessa) de caixa (extrato)",
     /Receita recorrente/.test(telaNegocio) && /o que entrou de verdade/.test(telaNegocio));
  ok("e mostra o que venceu sem pagamento", /caixa\.vencido/.test(telaNegocio));

  /**
   * ═════════════════════════════════════════════════════════════════════════
   * A FILA DE E-MAILS QUE NÃO ANDAVA.
   *
   * "e-mails proativos que nunca saem de próximos disparos": escritório sem
   * NENHUM usuário planeja e-mail em toda execução, não tem destinatário, e
   * volta amanhã igual. Eram 6 de 16 na base real. Misturados na mesma lista,
   * faziam o motor parecer quebrado.
   * ═════════════════════════════════════════════════════════════════════════
   */
  const telaEmails = fs.readFileSync(path.join(RAIZ, "app/painel/negocio/emails/page.tsx"), "utf8");
  /* olhar só por "separarFila" casava com a LINHA DO IMPORT e passava mesmo
     com a chamada trocada por `const sairao = previsao` — o defeito exato que
     a quebra proposital introduziu. A checagem é na chamada. */
  ok("a fila separa o que vai sair do que está travado sem destinatário",
     /=\s*separarFila\(previsao\)/.test(telaEmails) && /travados\.length/.test(telaEmails),
     (telaEmails.match(/const .*sairao.*=.*/) || ["não achei a chamada"])[0]);
  ok("e a contagem por grupo conta só o que REALMENTE sai",
     /for \(const p of sairao\)/.test(telaEmails));
  ok("o escritório órfão vira ação na fila do negócio, com conserto",
     /Escritório sem usuário/.test(fs.readFileSync(path.join(RAIZ, "lib/negocio.ts"), "utf8")));

  /* sem batimento, "o motor não rodou" e "rodou e não tinha nada" são
     indistinguíveis — e foi assim que a fila ficou dias parecendo entupida */
  /**
   * O CORPO DO CRON MUDOU DE ARQUIVO em 05/08/2026, e estas duas guardas
   * quebraram — o que é o comportamento certo delas.
   *
   * O que rodava dentro da rota foi para `lib/cron-negocio.ts`, porque agora
   * existem dois gatilhos: o Vercel Cron e o botão do painel. Enquanto eram
   * códigos diferentes, apertar o botão para reproduzir um problema do cron
   * reproduzia outra coisa — o botão só chamava as réguas.
   *
   * As guardas passam a ler o módulo, e ganharam uma terceira: a rota TEM de
   * delegar. Sem ela, alguém reimplementa o corpo na rota e os dois caminhos
   * divergem de novo, em silêncio.
   */
  const cronRota = fs.readFileSync(path.join(RAIZ, "app/api/cron/negocio/route.ts"), "utf8");
  const cron = fs.readFileSync(path.join(RAIZ, "lib/cron-negocio.ts"), "utf8");
  ok("cada execução do motor deixa um batimento", /reguas_execucao/.test(cron));
  ok("a rota do cron DELEGA para o módulo, em vez de ter cópia do corpo",
     /rodarCronNegocio\(/.test(cronRota) && !/executarReguas/.test(cronRota));
  ok("e o painel chama a MESMA função (um gatilho a mais, não um caminho a mais)",
     /rodarCronNegocio/.test(fs.readFileSync(path.join(RAIZ, "app/api/negocio/route.ts"), "utf8")));
  ok("e a tela mostra quando ele rodou pela última vez", /ultimaExec/.test(telaEmails));

  /**
   * ═════════════════════════════════════════════════════════════════════════
   * O CRON PRECISA CONSEGUIR LER A BASE — o bug mais caro desta sequência.
   *
   * `negocio_escritorios()` é SECURITY DEFINER e exigia superadmin. O cron usa
   * a service role, para quem `auth.uid()` é NULL: a função levantava
   * "acesso restrito". O erro era descartado (a linha desestruturava só o
   * `data`), a lista vinha vazia, e a resposta era {"planejados":0,"erros":[]}
   * — indistinguível de um dia sem nada a fazer. Dias mudos com a tela
   * mostrando 16 na fila, porque LÁ quem chama é a sessão do superadmin.
   * ═════════════════════════════════════════════════════════════════════════
   */
  const mig42 = path.join(RAIZ, "supabase/migrations/0042_cron_le_escritorios.sql");
  ok("existe a migration que deixa a service role ler os escritórios", fs.existsSync(mig42));
  if (fs.existsSync(mig42)) {
    const sql = fs.readFileSync(mig42, "utf8");
    /* A VARREDURA IGNORA COMENTÁRIOS, e isso não é detalhe: esta migration
       EXPLICA o bug em prosa, citando "service_role" e "current_user" no
       texto. Olhando o arquivo inteiro, a guarda passava mesmo com a
       liberação removida do código — porque a explicação continuava lá. */
    const codigo = sql.replace(/^\s*--.*$/gm, "");
    ok("a guarda nova aceita superadmin E service role",
       /= 'service_role'/.test(codigo) && /is_superadmin/.test(codigo),
       (codigo.match(/return[^;]*service_role[^;]*/) || ["não achei a liberação"])[0].trim());
    /* current_user dentro de SECURITY DEFINER é o DONO da função, não quem
       chamou: checar por ali daria "postgres" para todo mundo e liberaria geral */
    ok("...e não usa current_user, que mentiria dentro de SECURITY DEFINER",
       !/current_user/.test(codigo));
    ok("e a RPC de escritórios passou a usar a guarda nova",
       /negocio_escritorios[\s\S]*e_plataforma\(\)/.test(sql));
  }

  /**
   * ═════════════════════════════════════════════════════════════════════════
   * A TELA DE CONTAS PRECISA ENXERGAR AS CONTAS.
   *
   * Ela lê `tenants` pelo cliente do navegador, sujeita à RLS — e `tenants`
   * tinha UMA política: `id = tenant_atual()`. Uma linha, a própria. Era a
   * única tabela de plataforma sem política de gestor: faturas, chamados,
   * indicacoes, nps, ajuda, curso e assistente já tinham.
   * ═════════════════════════════════════════════════════════════════════════
   */
  const mig43 = path.join(RAIZ, "supabase/migrations/0043_contas_da_plataforma.sql");
  ok("existe a migration que deixa a plataforma ver todos os escritórios", fs.existsSync(mig43));
  if (fs.existsSync(mig43)) {
    const sql43 = fs.readFileSync(mig43, "utf8").replace(/^\s*--.*$/gm, "");
    ok("a política nova é sobre tenants e usa a guarda de plataforma",
       /on public\.tenants/.test(sql43) && /e_plataforma\(\)/.test(sql43));
    /* `tenants` é a raiz do grafo e as FK descem em CASCADE: um delete
       acidental na tela de administração apagaria a operação de um cliente */
    ok("...e NÃO concede delete (as FK descem em cascade)",
       !/for all/i.test(sql43) && !/for delete/i.test(sql43),
       (sql43.match(/for (all|delete)/i) || ["ok"])[0]);
  }

  /* A tela de Contas virou server component em 05/08/2026 e a gravação foi
     para `components/ContaLinha.tsx` — esta guarda seguiu o código, como a do
     cron. RLS que recusa escrita não devolve erro: devolve ZERO LINHAS. Sem
     pedir a linha de volta, a tela diz "salvo" tendo salvo nada. */
  const telaContas = fs.readFileSync(path.join(RAIZ, "components/ContaLinha.tsx"), "utf8");
  ok("a tela de contas confirma a gravação pedindo a linha de volta",
     /\.update\(campos\)[\s\S]{0,120}\.select\("id"\)/.test(telaContas) &&
     /!data\?\.length/.test(telaContas));
  /* e a tela é UMA: a de cobranças não pode voltar a editar assinatura por
     fora, que era a origem da divergência */
  ok("Faturas & régua não edita mais escritório (a fonte dupla acabou)",
     !/LinhaEscritorio/.test(fs.readFileSync(path.join(RAIZ, "app/painel/negocio/cobrancas/page.tsx"), "utf8")));

  /**
   * ═════════════════════════════════════════════════════════════════════════
   * A VARREDURA DE 04/08 — quatro defeitos que mandavam e-mail errado ou
   * perdiam dinheiro, cada um com sua guarda.
   * ═════════════════════════════════════════════════════════════════════════
   */
  {
    const rgc = fs.readFileSync(path.join(RAIZ, "lib/reguas.ts"), "utf8");

    /* o map de carregarContexto esquecia `termos`, e a régua "laudo sem termo"
       ia para quem tinha TODOS os termos — de novo a cada laudo novo */
    const iMap = rgc.indexOf("})) as EscritorioRegua[]");
    const mapa = iMap < 0 ? "" : rgc.slice(Math.max(0, iMap - 1600), iMap);
    ok("o contexto das réguas copia `termos` da RPC",
       /termos:\s*Number\(/.test(mapa), "o map não copia termos");
    ok("...e também is_teste / emails_optout, que decidem quem NÃO recebe",
       /is_teste:/.test(mapa) && /emails_optout:/.test(mapa));

    /* a chave-mestra não pode falhar aberta */
    ok("erro ao ler a config PARA o motor (senão as réguas religam sozinhas)",
       /cfgErro/.test(rgc) && /não consegui ler a configuração/.test(rgc));

    /* a escada de cobrança dependia de um vencimento que ninguém gravava */
    const ckv = fs.readFileSync(path.join(RAIZ, "app/api/checkout/route.ts"), "utf8");
    /* `vencimento: cobranca.vencimento` aparece DUAS vezes no arquivo (o
       update da assinatura e o upsert da fatura). Procurar no arquivo inteiro
       passava com o campo removido do update da assinatura — que é o único que
       a escada de cobrança lê. A checagem é no bloco certo. */
    const iUpd = ckv.indexOf('.from("assinaturas")\n      .update(');
    const upd = iUpd < 0 ? "" : ckv.slice(iUpd, iUpd + 320);
    ok("o checkout grava o vencimento NA ASSINATURA (sem ele a escada não cobra)",
       /vencimento: cobranca\.vencimento/.test(upd),
       upd.replace(/\s+/g, " ").slice(0, 150) || "não achei o update da assinatura");
    ok("e reserva a chave da régua ao mandar o link (senão vai duas vezes)",
       /chave_unica: `cobranca_gerada:\$\{assinatura\.id\}`/.test(ckv));
  }

  {
    const wh2 = fs.readFileSync(path.join(RAIZ, "app/api/asaas/route.ts"), "utf8");
    /* PAYMENT_CHECKOUT_VIEWED e afins caíam no default "pendente" e eram
       gravados por cima de uma fatura PAGA, apagando o pago_em */
    /* olhar só por "jaLiquidada" casava com a DECLARAÇÃO e passava com a
       condição trocada por `if (false)` — a checagem é no if */
    ok("evento inócuo não derruba fatura já liquidada",
       /if \(jaLiquidada && status === "pendente"\)/.test(wh2) && /doPagamento/.test(wh2),
       (wh2.match(/if \([^)]*jaLiquidada[^)]*\)/) || ["não achei a guarda"])[0]);
    /* data-calendário do Asaas não pode virar new Date(): seria o dia anterior */
    ok("o pago_em não perde um dia no fuso",
       /T12:00:00-03:00/.test(wh2) && !/pago_em: pagoEm \? new Date\(pagoEm\)/.test(wh2));

    const as2 = fs.readFileSync(path.join(RAIZ, "lib/asaas.ts"), "utf8");
    /* "sincronizar" ativava a assinatura e deixava a fatura "em aberto" — foi
       o bug que o dono teve que consertar na mão */
    const iRec = as2.indexOf("export async function reconciliarAssinatura");
    const rec = iRec < 0 ? "" : as2.slice(iRec, as2.indexOf("export async function importarFaturas"));
    ok("sincronizar também marca a FATURA como paga",
       /\.from\("faturas"\)/.test(rec) && /status: "pago"/.test(rec),
       "reconciliarAssinatura não toca em faturas");
  }

  {
    const ng = fs.readFileSync(path.join(RAIZ, "app/api/negocio/route.ts"), "utf8");
    /* a tela manda o objeto de config inteiro com um `base` congelado: sem
       merge no servidor, ajustar um campo religava as réguas desligadas */
    ok("a configuração é mesclada no servidor, não substituída",
       /\.\.\.anterior, \.\.\.\(valor as Record<string, unknown>\)/.test(ng));
    /* a assinatura era inserida ANTES de validar o documento, e o 400 não
       desfazia: cada clique deixava uma pendente fantasma que silenciava as
       réguas de conversão daquele escritório */
    ok("gerar_cobranca valida o documento ANTES de criar a assinatura",
       ng.indexOf("ainda não tem CPF/CNPJ cadastrado") < ng.indexOf('origem: "painel"'));
    ok("e o motivo do Asaas sobe em vez de virar ok:true",
       /cob\.ativo && !cob\.checkout_url/.test(ng));
  }

  /**
   * ═════════════════════════════════════════════════════════════════════════
   * A SEGUNDA LEVA DA VARREDURA — o que estava triado e agora está fechado.
   * ═════════════════════════════════════════════════════════════════════════
   */
  {
    const wh3 = fs.readFileSync(path.join(RAIZ, "app/api/asaas/route.ts"), "utf8");

    /* dinheiro devolvido tem que derrubar o acesso; chargeback ABERTO é
       acusação, não veredito — cortar quem talvez tenha razão custa o cliente */
    ok("estorno concluído revoga o acesso",
       /const DEVOLVIDO = new Set/.test(wh3) && /if \(devolvido && assinaturaId\)/.test(wh3));
    ok("...e chargeback apenas ABERTO mantém o acesso",
       /const CONTESTADO = new Set/.test(wh3) && /contestado: true/.test(wh3));

    /* 200 sem ter gravado faz o Asaas descartar o evento para sempre */
    ok("sem service role o webhook devolve 5xx, para o Asaas reenviar",
       /if \(!admin\)[\s\S]{0,240}status: 503/.test(wh3));

    /* reprocessamento não pode tirar acesso já concedido */
    ok("a validade nunca regride num evento repetido",
       /jaTinha && jaTinha > data \? jaTinha : data/.test(wh3));

    /* as colunas que a aba Contas soma e ninguém escrevia */
    ok("o pagamento alimenta as colunas de cobrança do escritório",
       /ultimo_pagamento:/.test(wh3) && /valor_mensal: mensalizado/.test(wh3));
  }

  {
    const aj = fs.readFileSync(path.join(RAIZ, "app/painel/negocio/ajuda/page.tsx"), "utf8");
    /* coluna que o formulário grava tem que ser coluna que o formulário leu */
    const sel = (aj.match(/\.select\("id, slug[^"]*"\)/) || [""])[0];
    ok("o editor de ajuda LÊ tipo e destaque antes de gravá-los",
       /tipo/.test(sel) && /destaque/.test(sel), sel || "não achei o select");
    ok("e publicado_em só é gravado na PRIMEIRA publicação",
       /!jaPublicadoEm \? \{ publicado_em/.test(aj));

    const ncalc = fs.readFileSync(path.join(RAIZ, "lib/negocio.ts"), "utf8");
    ok("MRR em risco não conta o mesmo escritório duas vezes", /emRisco\.set\(e\.id, e\)/.test(ncalc));
    /* procurar só pelo nome da variável passava com a CONTA revertida: a
       declaração continuava lá, sem ninguém usar. A checagem é na expressão. */
    ok("a conversão do funil não passa de 100%",
       /const conversao = comLaudo \? Math\.round\(\(provaramEPagaram \/ comLaudo\)/.test(ncalc),
       (ncalc.match(/const conversao = [^;]*/) || ["não achei a conta"])[0]);
    ok("e o painel avisa quando um número zerou por falha de leitura",
       /avisos\.push/.test(ncalc));

    const calc2 = fs.readFileSync(path.join(RAIZ, "lib/negocio-calc.ts"), "utf8");
    /* o mês em UTC zerava o caixa depois das 21h do dia 31 */
    ok("o mês do caixa é o do calendário brasileiro",
       /export function mesBr/.test(calc2) && !/hoje\.toISOString\(\)\.slice\(0, 7\)/.test(calc2));
  }

  {
    const rg2 = fs.readFileSync(path.join(RAIZ, "lib/reguas.ts"), "utf8");
    /* degrau desligado não pode bloquear os de baixo */
    ok("a escada de cobrança só considera degrau LIGADO",
       /\.filter\(\(\[chave\]\) => !!regras\[chave\]\)/.test(rg2));
    /* a régua cobre um período; a chave por fase mandava dois e-mails iguais */
    ok("o pós-janela é um toque só, não um por fase",
       /`pos_janela_revisao:\$\{e\.id\}`/.test(rg2));
    /* aviso de vencimento pressupõe que já houve tempo de pagar */
    ok("o pré-vencimento não sai na rodada em que a cobrança nasce",
       /!geradaSaiAgora/.test(rg2));
    /* o corte de cota caía sempre nos mesmos, e em quem nem podia receber */
    ok("o limite por execução corta quem VAI sair, não quem está travado",
       /out\.filter\(\(x\) => !!x\.para\)\.slice\(0, teto\)/.test(rg2));
    ok("e as vencidas são apuradas pelo dia do Brasil",
       /America\/Sao_Paulo/.test(rg2.slice(rg2.indexOf("export async function vencidasPendentes"))));

    const ng2 = fs.readFileSync(path.join(RAIZ, "app/api/negocio/route.ts"), "utf8");
    /* a MENSAGEM continua no arquivo mesmo com a guarda desligada (`if (false)`):
       a checagem é na condição */
    ok("plano com identificador vazio é recusado",
       /if \(!id\) \{/.test(ng2) && /Não consegui derivar um identificador/.test(ng2),
       (ng2.match(/if \(![a-z]+\) \{[\s\S]{0,60}derivar/) || ["a guarda do id sumiu"])[0].slice(0, 60));

    /**
     * `indexOf` DE ALGO QUE NÃO EXISTE É -1, e -1 é menor que tudo: a
     * comparação de ordem passava justamente quando a checagem era REMOVIDA.
     * Exigir a presença antes de comparar a ordem é o que fecha o buraco.
     */
    const iExiste = ng2.indexOf('.select("id").eq("id", id).maybeSingle()');
    const iLimpa = ng2.indexOf("destaque: false");
    ok("o destaque só é limpo depois de confirmar que o plano existe",
       iExiste >= 0 && iLimpa >= 0 && iExiste < iLimpa,
       { confirmacao: iExiste, limpeza: iLimpa });
    ok("limpar a data de acesso também espelha em valido_ate",
       /"vencimento" in patch/.test(ng2));
  }

  /**
   * ═════════════════════════════════════════════════════════════════════════
   * O AVISO AO CONTATIA — a costura que era manual.
   *
   * Sem ele, quem cria conta na terça recebe "você conhece o Enquadria?" na
   * quarta, porque continua na cadência de prospecção até alguém aplicar a tag
   * à mão. As guardas abaixo protegem as três propriedades que fazem isto
   * poder existir num caminho crítico.
   * ═════════════════════════════════════════════════════════════════════════
   */
  {
    const ct = fs.readFileSync(path.join(RAIZ, "lib/contatia.ts"), "utf8");

    /* o segredo não pode trafegar: assina-se `timestamp.corpo` */
    ok("o aviso é assinado com HMAC sobre timestamp+corpo",
       /createHmac\("sha256", segredo\)/.test(ct) && /\$\{ts\}\.\$\{corpo\}/.test(ct));
    /* sem timeout, um CRM lento vira espera na cara de quem confirmou o e-mail */
    ok("...com timeout, para não segurar o cadastro", /AbortController/.test(ct) && /TIMEOUT_MS/.test(ct));
    /* a função NÃO pode lançar: ela roda no meio do login */
    ok("...e nunca lança: devolve o motivo em vez de estourar",
       /catch \(e\)/.test(ct) && !/throw /.test(ct));

    const cb = fs.readFileSync(path.join(RAIZ, "app/auth/callback/route.ts"), "utf8");
    ok("o cadastro ativo é avisado na confirmação do e-mail",
       /avisarContatia/.test(cb) && /cadastro_ativo/.test(cb));
    /* a chave é o TENANT: clicar duas vezes no link de confirmação não pode
       inscrever a pessoa duas vezes na cadência do outro lado */
    ok("...com chave idempotente por escritório",
       /chaveDe\("cadastro_ativo", tenantId \?\? user\.id\)/.test(cb));
    /* falha do CRM não pode impedir alguém de entrar no produto */
    /* 08/08/2026: a versão anterior media a DISTÂNCIA em caracteres entre o
       `try {` e o `avisarContatia` (900 no máximo). Isso não testava a
       propriedade — testava o tamanho do bloco: acrescentar qualquer coisa
       dentro do mesmo try quebrava o teste sem que nada tivesse piorado. Agora
       o bloco é extraído e a pergunta é a certa: a chamada está DENTRO dele? */
    const blocoTry = cb.slice(cb.indexOf("try {"), cb.lastIndexOf("} catch"));
    ok("...dentro de try/catch, sem segurar o redirecionamento",
       blocoTry.includes("avisarContatia") && /\} catch/.test(cb));

    const wh4 = fs.readFileSync(path.join(RAIZ, "app/api/asaas/route.ts"), "utf8");
    ok("quem paga vira 'Cliente', com evento próprio",
       /evento: "assinatura_ativa"/.test(wh4));

    const ng3 = fs.readFileSync(path.join(RAIZ, "app/api/negocio/route.ts"), "utf8");
    ok("existe reprocesso para quem se cadastrou antes do webhook",
       /case "avisar_contatia"/.test(ng3));
    /* conta de teste marcada no painel não pode entrar no CRM */
    ok("...que respeita is_teste e pula escritório sem usuário",
       /if \(t\.is_teste\)/.test(ng3) && /if \(!email\)/.test(ng3));
  }

  const rg = fs.readFileSync(path.join(RAIZ, "lib/reguas.ts"), "utf8");
  /* olhar por "error" no arquivo inteiro casaria com qualquer coisa: a
     checagem é na desestruturação da RPC, que era exatamente o que faltava */
  ok("o contexto das réguas LÊ o erro da RPC em vez de descartá-lo",
     /\{ data: escRaw, error: escErro \}/.test(rg),
     (rg.match(/const \[\{ data: escRaw[^\]]*/) || ["não achei a leitura"])[0].slice(0, 90));
  ok("e fonte quebrada não vira fila vazia silenciosa",
     /if \(ctx\.erro\)/.test(rg) && /erros: \[ctx\.erro\]/.test(rg));
  ok("o cron não relata 0 planejados sem dizer nada",
     /planejados === 0 && !r\.erros\.length/.test(cron));

  const tela = fs.readFileSync(path.join(RAIZ, "app/painel/planos/page.tsx"), "utf8");
  ok("a tela de planos tem onde mostrar o erro da contratação",
     /erroCheckout/.test(tela));
  ok("e trata o pop-up bloqueado, que também parece clique perdido",
     /bloqueou a janela/.test(tela));
}

/* ============================================== 2. A MASSA NO PARSER ==== */
secao("Massa de empresas no parser do app");
const GOLDEN_IMPORT = { lidas: 47, importadas: 45, duplicadas: 1, descartadas: 1 };
const GOLDEN_FAIXAS = { A: 23, B: 6, C: 1, D: 9, MEI: 2, FORA: 4 };

if (!fs.existsSync(CSV)) {
  ok("CSV da massa encontrado", false, CSV);
} else {
  const r = csvlib.parsearCarteira(fs.readFileSync(CSV, "utf8"));
  ok(`lê ${GOLDEN_IMPORT.lidas} linhas`, r.total_lidas === GOLDEN_IMPORT.lidas, r.total_lidas);
  ok(`importa ${GOLDEN_IMPORT.importadas}`, r.linhas.length === GOLDEN_IMPORT.importadas, r.linhas.length);
  ok(`acha ${GOLDEN_IMPORT.duplicadas} duplicada`, r.duplicadas === GOLDEN_IMPORT.duplicadas, r.duplicadas);
  ok(`descarta ${GOLDEN_IMPORT.descartadas}`, r.descartadas === GOLDEN_IMPORT.descartadas, r.descartadas);

  const email = r.linhas.find((l) => l.razao_social.includes("Formato Estranho"));
  ok("e-mail inválido NÃO é gravado", email && !email.contato_email, email?.contato_email);
  ok("RBT12 escrito como moeda vira número", email?.rbt12 === 1850000, email?.rbt12);
  const semNome = r.linhas.find((l) => l.razao_social === "(sem razão social)");
  ok("linha sem razão social entra com rótulo", !!semNome);
  const faixaTxt = r.linhas.find((l) => l.razao_social.includes("Faixa Textual"));
  ok("faturamento em faixa textual não vira RBT12", faixaTxt && faixaTxt.rbt12 === undefined, faixaTxt?.rbt12);

  const dist = {};
  for (const l of r.linhas) {
    const t = triagem.triar({
      cnpj: l.cnpj, razao_social: l.razao_social, cnae_principal: l.cnae_principal,
      porte: l.porte, situacao: l.situacao, regime: l.regime,
      faturamento_faixa: l.faturamento_faixa,
    });
    dist[t.faixa] = (dist[t.faixa] || 0) + 1;
  }
  for (const [f, n] of Object.entries(GOLDEN_FAIXAS)) {
    ok(`triagem: faixa ${f} = ${n}`, dist[f] === n, dist[f]);
  }
  ok("prioridade máxima na de faixa textual",
     triagem.triar({ cnpj: faixaTxt?.cnpj ?? "", razao_social: "x", cnae_principal: "4639-7/01",
                     porte: "EPP", situacao: "ATIVA", regime: "Simples Nacional",
                     faturamento_faixa: "acima de 3,6mi" }).prioridade_maxima === true);

  /* ═══ OS VALORES COMO OS SISTEMAS ESCREVEM (07/08/2026) ═══════════════════
     A primeira carteira REAL veio com o regime em sigla e a triagem jogou
     TUDO em FORA — o produto pareceu não ter lido o arquivo. E o inverso,
     silencioso: "Não" numa coluna não reconhecida deixava Presumido entrar
     na fila como optante. Estes casos são a carteira real, não a de exemplo. */
  const triaCom = (regime, extra = {}) => triagem.triar({
    cnpj: "33000167000101", razao_social: "x", cnae_principal: "2599-3/99",
    porte: "EPP", situacao: "ATIVA", regime, ...extra,
  }).faixa;
  ok("regime 'SN' é Simples (era o bug: virava FORA)", triaCom("SN") === "A", triaCom("SN"));
  ok("regime 'Sim' é Simples", triaCom("Sim") === "A", triaCom("Sim"));
  ok("regime 'Optante' é Simples", triaCom("Optante") === "A", triaCom("Optante"));
  ok("regime '1 - Simples Nacional' é Simples", triaCom("1 - Simples Nacional") === "A");
  ok("regime 'Não' é FORA (o silencioso: entrava na fila)", triaCom("Não") === "FORA", triaCom("Não"));
  ok("regime 'Não optante' é FORA — a negação vence o 'optante' contido",
     triaCom("Não optante") === "FORA", triaCom("Não optante"));
  ok("regime 'Lucro Presumido' segue FORA", triaCom("Lucro Presumido") === "FORA");
  ok("porte por extenso vira MEI", triaCom("Simples Nacional", { porte: "MICROEMPREENDEDOR INDIVIDUAL" }) === "MEI");
  ok("situação desconhecida NÃO derruba (falso-FORA é carteira sumindo)",
     triaCom("Simples Nacional", { situacao: "Habilitada" }) === "A");
  ok("situação '8 - BAIXADA' derruba", triaCom("Simples Nacional", { situacao: "8 - BAIXADA" }) === "FORA");

  /* o cabeçalho também: a coluna dos exports reais tem que cair em REGIME */
  const cab = (csv) => csvlib.parsearCarteira(csv).colunas_reconhecidas;
  const c1 = cab("CNPJ;Optante pelo Simples\n33.000.167/0001-01;Sim");
  ok("coluna 'Optante pelo Simples' cai em regime (era ignorada)", c1.regime === "Optante pelo Simples", c1);
  const c2 = cab("CNPJ;Situação Simples Nacional\n33.000.167/0001-01;Optante");
  ok("coluna 'Situação Simples Nacional' cai em REGIME, não em situação",
     c2.regime === "Situação Simples Nacional" && !c2.situacao, c2);
  const c3 = cab("CNPJ;Situação Cadastral\n33.000.167/0001-01;ATIVA");
  ok("'Situação Cadastral' continua caindo em situação", c3.situacao === "Situação Cadastral", c3);
  const c4 = cab("CNPJ;Anexo Simples\n33.000.167/0001-01;2");
  ok("'Anexo Simples' continua caindo em anexo, não em regime", c4.anexo === "Anexo Simples", c4);


}

/* ═══ A COLUNA DE ANEXO LIDA COMO REGIME (08/08/2026) ══════════════════════
   O caso que o teste acima quase pegava e não pegava: "Anexo Simples" tem 13
   caracteres e vence "simples" (7) — mas "Anexo Simples NACIONAL" contém
   "simples nacional", de 16, e 16 vence 13. A coluna com os valores 1..5 ia
   para REGIME, `leRegime("3")` devolvia "fora", e toda empresa de Anexo II a
   V sumia da fila rotulada "Empresa já fora do Simples". Em silêncio: a rede
   do importador só acende acima de 55% de FORA, e o Anexo I continuava
   entrando como optante, segurando o total abaixo do corte.
   É o defeito mais caro que este produto pode ter — acontece no primeiro
   contato, com a carteira real, e o contador conclui que o produto não leu o
   arquivo dele. Duas travas: o mapeamento da coluna e a leitura do valor. */
/* helper próprio: estes casos rodam SEMPRE, inclusive em máquina sem o CSV de
   conferência. O defeito que eles guardam é caro demais para ficar atrás de um
   arquivo que pode não estar lá — foi assim que ele passou despercebido. */
const cabecalhoDe = (csv) => csvlib.parsearCarteira(csv).colunas_reconhecidas;

const c5 = cabecalhoDe("CNPJ;Anexo Simples Nacional\n33.000.167/0001-01;3");
ok("'Anexo Simples Nacional' cai em ANEXO, não em regime (a carteira sumia)",
   c5.anexo === "Anexo Simples Nacional" && !c5.regime, c5);
const c6 = cabecalhoDe("CNPJ;ANEXO DO SIMPLES NACIONAL\n33.000.167/0001-01;5");
ok("qualquer cabeçalho que comece com 'anexo' é anexo", c6.anexo === "ANEXO DO SIMPLES NACIONAL", c6);

const linhaAnexo = csvlib.parsearCarteira(
  "CNPJ;Razao Social;Anexo Simples Nacional;CNAE\n33.000.167/0001-01;ACME;3;2599399"
).linhas[0];
ok("...e o valor vira o anexo da empresa", linhaAnexo.anexo === 3, linhaAnexo.anexo);
ok("...com o regime intocado, para a triagem decidir pelo CNAE",
   linhaAnexo.regime === undefined, linhaAnexo.regime);
ok("...e a empresa entra na fila em vez de sumir",
   triagem.triar(linhaAnexo).faixa === "A", triagem.triar(linhaAnexo).faixa);

/* a segunda trava: dígito sozinho é anexo, não regime — "não sei" segue pela
   triagem por CNAE, "fora" some da tela */
ok("leRegime('3') é 'não sei', não 'fora'", triagem.leRegime("3") === null, triagem.leRegime("3"));
ok("leRegime('1') idem — sem inventar que é optante", triagem.leRegime("1") === null);
ok("mas '1 - Simples Nacional' continua sendo Simples",
   triagem.leRegime("1 - Simples Nacional") === "simples");

/* o anexo em romano vinha do export e virava NaN, caindo no chute por CNAE */
ok("parseAnexo lê romano", csvlib.parseAnexo("Anexo III") === 3, csvlib.parseAnexo("Anexo III"));
ok("parseAnexo lê 'ANEXO V'", csvlib.parseAnexo("ANEXO V") === 5, csvlib.parseAnexo("ANEXO V"));
ok("parseAnexo lê dígito", csvlib.parseAnexo("2") === 2);
ok("parseAnexo recusa lixo", csvlib.parseAnexo("x") === undefined);
ok("parseAnexo recusa fora da faixa 1..5", csvlib.parseAnexo("9") === undefined);

/* ═══ O CSV QUE SOBROU (08/08/2026) ════════════════════════════════════════
   Cinco defeitos do mesmo tipo: o arquivo é lido, alguma coisa se perde, e
   NADA na tela conta. Os quatro primeiros grupos guardam consertos do parser;
   o último lê a tela, porque o defeito era ela contradizer o parser.

   Estes casos rodam SEMPRE, sem depender do CSV de conferência — foi debaixo
   dessa dependência que a coluna de anexo passou despercebida. ═════════════ */
secao("O CSV que sobrou: coluna trocada, linha perdida e aviso engolido");
{
  /* ── 1 · COLISÃO DE SINÔNIMO: a coluna que parece outra ─────────────────
     "Inscrição Estadual" casava `cnpj` pelo sinônimo "inscricao". Vindo ANTES
     do CNPJ no arquivo ela ficava com a vaga, todo documento era inválido, e
     como `colunas_reconhecidas.cnpj` existia o erro específico não disparava:
     o contador lia "confira os 14 dígitos" sobre documentos corretos. */
  const cIE = cabecalhoDe("Inscrição Estadual;CNPJ;Razão Social\n123456789;33.000.167/0001-01;ACME");
  ok("'Inscrição Estadual' NÃO ocupa a vaga do CNPJ, mesmo vindo antes",
     cIE.cnpj === "CNPJ", cIE);
  ok("...e a coluna vetada aparece na lista do que não usei (visível, não sumida)",
     csvlib.parsearCarteira("Inscrição Estadual;CNPJ\n123;33.000.167/0001-01")
       .colunas_ignoradas.includes("Inscrição Estadual"));
  ok("'Inscrição Municipal' também não vira CNPJ",
     cabecalhoDe("CNPJ;Inscrição Municipal\n33.000.167/0001-01;99").cnpj === "CNPJ");
  ok("e o cabeçalho 'CNPJ' continua sendo CNPJ (o veto não pode comer o certo)",
     cabecalhoDe("CNPJ\n33.000.167/0001-01").cnpj === "CNPJ");

  /* nome fantasia não tem valor jurídico e ia para a capa do laudo e do termo */
  const cNF = cabecalhoDe("CNPJ;Nome Fantasia;Razão Social\n33.000.167/0001-01;Padaria da Ana;Ana Alimentos ME");
  ok("'Nome Fantasia' não vence 'Razão Social' quando as duas existem",
     cNF.razao_social === "Razão Social", cNF);
  const soFantasia = csvlib.parsearCarteira("CNPJ;Nome Fantasia\n33.000.167/0001-01;Padaria da Ana");
  ok("...e sozinha ela também não vira razão social — o nome vem da Receita",
     !soFantasia.colunas_reconhecidas.razao_social &&
     soFantasia.linhas[0].razao_social === "(sem razão social)", soFantasia.linhas[0].razao_social);

  /* o contador do escritório virava o signatário do termo do cliente dele */
  const cCT = cabecalhoDe("CNPJ;Contador Responsável;Responsável\n33.000.167/0001-01;João;Maria");
  ok("'Contador Responsável' não vira o signatário do termo do cliente",
     cCT.contato_nome === "Responsável", cCT);
  ok("...e 'Responsável' sozinho continua sendo o contato",
     cabecalhoDe("CNPJ;Responsável\n33.000.167/0001-01;Maria").contato_nome === "Responsável");

  /* ── 2 · A LINHA DESCARTADA TEM NOME ────────────────────────────────────
     "2 descartadas" numa carteira de 300 é a mesma informação que nada: o
     contador sabe que perdeu clientes e não sabe quais nem onde corrigir. */
  const rej = csvlib.parsearCarteira(
    "CNPJ;Razão Social\n11.222.333/0001-99;Padaria Aurora\n07.526.557/0001-00;Casa Nova\n" +
    "07.526.557/0001-00;Casa Nova 2\nxxx;"
  );
  ok("a lista de rejeitadas nomeia o CNPJ com DV inválido",
     rej.rejeitadas[0].motivo === "cnpj_invalido" &&
     rej.rejeitadas[0].razao_social === "Padaria Aurora", rej.rejeitadas[0]);
  ok("...com o documento COMO VEIO no arquivo, que é como ele o acha na planilha",
     rej.rejeitadas[0].cnpj_bruto === "11.222.333/0001-99", rej.rejeitadas[0].cnpj_bruto);
  ok("...a repetida entra com o motivo 'duplicada'",
     rej.rejeitadas[1].motivo === "duplicada" && rej.rejeitadas[1].razao_social === "Casa Nova 2",
     rej.rejeitadas[1]);
  ok("...razão social vazia vira null, e não string vazia (a tela decide o rótulo)",
     rej.rejeitadas[2].razao_social === null, rej.rejeitadas[2]);
  ok("...e os contadores agregados continuam batendo com a lista",
     rej.descartadas === 2 && rej.duplicadas === 1 &&
     rej.rejeitadas.length === rej.descartadas + rej.duplicadas,
     [rej.descartadas, rej.duplicadas, rej.rejeitadas.length]);

  /* a lista tem teto; a CONTAGEM não pode ter — ela é o que vai para o banco */
  const muitas = csvlib.parsearCarteira(
    "CNPJ\n" + Array.from({ length: 60 }, (_, i) => `1122233300019${i % 10}`).join("\n")
  );
  ok("60 linhas ruins: a lista para em 50 e a contagem segue exata",
     muitas.rejeitadas.length === 50 && muitas.descartadas + muitas.duplicadas === 60,
     [muitas.rejeitadas.length, muitas.descartadas, muitas.duplicadas]);

  /* ── 3 · `parsed.errors` ERA DESCARTADO ─────────────────────────────────
     Uma aspa aberta e não fechada engole o resto do arquivo dentro de um campo
     só: o parse termina sem lançar nada, a carteira de 300 chega com 1, e a
     tela comemora. O aviso do papaparse existia e ninguém lia. */
  const aspas = csvlib.parsearCarteira(
    'CNPJ;Razão Social\n33.000.167/0001-01;"Padaria Aurora\n07.526.557/0001-00;Casa Nova\n22.333.444/0001-81;Vale Verde'
  );
  ok("aspas abertas: o arquivo trunca e agora a tela tem o que dizer",
     aspas.linhas.length === 1 && aspas.erros_leitura.length === 1,
     [aspas.linhas.length, aspas.erros_leitura]);
  ok("...o aviso está em português e cita a linha do ARQUIVO, não o índice",
     /^Linha 2: /.test(aspas.erros_leitura[0]) && /aspas/.test(aspas.erros_leitura[0]),
     aspas.erros_leitura[0]);
  ok("...e não sobrou inglês do papaparse",
     !/quoted|field|delimiter/i.test(aspas.erros_leitura[0]), aspas.erros_leitura[0]);
  const sobra = csvlib.parsearCarteira("CNPJ,Razão Social\n33.000.167/0001-01,ACME,sobra\n07.526.557/0001-00,Casa Nova");
  ok("linha com mais colunas que o cabeçalho também é relatada, com a linha",
     /^Linha 2: .*colunas/.test(sobra.erros_leitura[0] ?? ""), sobra.erros_leitura);
  ok("arquivo bem formado não inventa aviso nenhum",
     csvlib.parsearCarteira("CNPJ;Razão Social\n33.000.167/0001-01;ACME").erros_leitura.length === 0);

  /* ── 4 · RBT12 ABAIXO DE MIL, RECUSADO EM SILÊNCIO ──────────────────────
     A regra do parser NÃO muda: sem o corte de R$ 1.000, o "3" de uma coluna
     de faixa viraria receita. O que faltava era a tela distinguir "o arquivo
     não tem RBT12" de "o arquivo tem e eu recusei todos". */
  ok("parseValorBRL('480') segue recusado — a regra não foi afrouxada",
     csvlib.parseValorBRL("480") === undefined, csvlib.parseValorBRL("480"));
  ok("parseValorBRL('480000') segue aceito", csvlib.parseValorBRL("480000") === 480000);
  ok("parseValorBRL('1.200.000,00') segue aceito", csvlib.parseValorBRL("1.200.000,00") === 1200000);
  ok("pareceValorEmMilhares reconhece o número pequeno", csvlib.pareceValorEmMilhares("480") === true);
  ok("...e não confunde faixa textual com valor em milhares",
     csvlib.pareceValorEmMilhares("acima de 3,6mi") === false);
  const mil = csvlib.parsearCarteira("CNPJ;RBT12\n33.000.167/0001-01;480\n07.526.557/0001-00;220");
  ok("planilha em milhares: nenhum RBT12 aceito, e a tela sabe por quê",
     mil.rbt12_recusados === 2 && mil.rbt12_em_milhares === 2 &&
     mil.linhas.every((l) => l.rbt12 === undefined),
     [mil.rbt12_recusados, mil.rbt12_em_milhares]);
  const faixa = csvlib.parsearCarteira("CNPJ;Faturamento\n33.000.167/0001-01;acima de 3,6mi");
  ok("faixa textual conta como recusada, mas NÃO como milhares",
     faixa.rbt12_recusados === 1 && faixa.rbt12_em_milhares === 0,
     [faixa.rbt12_recusados, faixa.rbt12_em_milhares]);
  ok("RBT12 de verdade não acusa nada",
     csvlib.parsearCarteira("CNPJ;RBT12\n33.000.167/0001-01;480000").rbt12_recusados === 0);

  /* ── 5 · A TELA CONTRADIZIA O PARSER ────────────────────────────────────
     Ela dizia "Só o CNPJ é obrigatório" e, seis linhas acima, marcava a razão
     social como essencial: chip vermelho e rodapé no plural. O parser nunca
     barrou a falta do nome. Vermelho gasto em campo opcional ensina a ignorar
     vermelho — inclusive o do CNPJ, que barra de verdade. */
  const imp = fs.readFileSync(path.join(RAIZ, "components/Importador.tsx"), "utf8");
  ok("só o CNPJ é marcado como essencial na tabela de campos",
     (imp.match(/essencial: true/g) || []).length === 1,
     (imp.match(/essencial: true/g) || []).length);
  ok("a razão social não é mais campo essencial",
     !/chave: "razao_social"[^\n]*essencial/.test(imp));
  ok("o rodapé da tabela fala de UM obrigatório", /\* o único obrigatório/.test(imp));
  ok("e a frase de sempre continua dizendo a mesma coisa",
     /Só o CNPJ é obrigatório/.test(imp));

  /* a tela precisa MOSTRAR o que o parser passou a devolver, senão o conserto
     morre na metade do caminho */
  ok("a tela lista quem ficou de fora", /parse\.rejeitadas/.test(imp) && /MOTIVO_REJEICAO/.test(imp));
  ok("a tela mostra os avisos de leitura do arquivo", /parse\.erros_leitura/.test(imp));
  ok("a tela explica o RBT12 recusado em bloco e sugere os milhares",
     /rbt12_recusados/.test(imp) && /milhares/.test(imp));
}

/* ══ A ABA SEGUE A AÇÃO, E A TELA DIZ O QUE FAZER (07/08/2026) ═════════════
   "Confirmar premissas" abria o Dossiê quando a gaveta já estava aberta:
   `useState(abaInicial)` lê a prop uma vez, e a gaveta não desmonta entre um
   clique e outro. O contador via a ficha, não o formulário — e concluía que
   não havia o que analisar. ══════════════════════════════════════════════ */
secao("Primeiro acesso da empresa: a aba certa e a instrução certa");
{
  const painel = fs.readFileSync(path.join(RAIZ, "components/PainelEmpresa.tsx"), "utf8");
  ok("a aba sincroniza quando a ação muda de destino",
     /useEffect\(\s*\(\)\s*=>\s*\{\s*setAba\(abaInicial\);?\s*\}\s*,\s*\[abaInicial\]\)/.test(painel));

  const cock = fs.readFileSync(path.join(RAIZ, "components/Cockpit.tsx"), "utf8");
  /* 08/08/2026: a regra saiu do ternário escrito no Cockpit e virou o mapa
     `DESTINO_DA_ACAO`, em lib/cockpit.ts — a mesma fonte que a Trilha lê. Havia
     TRÊS cópias da mesma decisão (Cockpit, Trilha e um `ACAO_ABRE_GAVETA` sem
     nenhum importador, que declarava o oposto das outras duas). Este teste
     passa a conferir o mapa, que é o que agora governa o clique. */
  ok("a ação de confirmar/analisar abre a ANÁLISE, não o dossiê",
     cockLib.DESTINO_DA_ACAO.confirmar.aba === "decisao" &&
     cockLib.DESTINO_DA_ACAO.analisar.aba === "decisao",
     cockLib.DESTINO_DA_ACAO.confirmar);
  ok("...e 'cadastrar contato' abre o DOSSIÊ, que é onde o dado que falta mora",
     cockLib.DESTINO_DA_ACAO.contato.aba === "dossie", cockLib.DESTINO_DA_ACAO.contato);
  ok("sem trabalho pendente não há destino — o botão fica apagado",
     cockLib.DESTINO_DA_ACAO.pronto.tipo === "nenhum" &&
     cockLib.DESTINO_DA_ACAO.fora.tipo === "nenhum");
  ok("o Cockpit LÊ o mapa em vez de reescrever a regra",
     /DESTINO_DA_ACAO\[l\.acao\]/.test(cock));
  /* ESTE TESTE MEDIA A LINHA, NÃO A REGRA — reescrito em 10/08/2026.
     Ele exigia o texto exato `aba: l.analise_id ? "dossie" : "decisao"`. Quando
     o clique ganhou um terceiro destino (a aba dos pontos da Reforma, quando a
     fila está filtrada por eles), o teste quebrou sem que nada piorasse: a
     regra antiga continua valendo, só deixou de caber numa linha. Agora ele
     recorta o handler do nome e confere os TRÊS destinos — o que é uma trava
     mais forte, não mais fraca. */
  const iNome = cock.indexOf('className="min-w-0 flex-1 text-left');
  const cliqueNome = iNome > 0 ? cock.slice(Math.max(0, iNome - 900), iNome) : "";
  ok("clicar no nome de empresa SEM análise leva ao formulário",
     /l\.analise_id[\s\S]{0,80}"dossie"[\s\S]{0,40}"decisao"/.test(cliqueNome),
     cliqueNome.slice(-220));
  ok("...e, com o filtro dos pontos da Reforma ligado, abre a aba deles",
     /reforma_pendente[\s\S]{0,120}"apontamentos"/.test(cliqueNome),
     cliqueNome.slice(-220));

  /* ═══ os apontamentos deixaram de existir em dois lugares (10/08/2026) ═══
     A tela /painel/apontamentos mostrava as MESMAS linhas, com os MESMOS três
     botões, que a ficha da empresa. Quem tratava num lugar não sabia se tinha
     tratado no outro, e o ponto voltava a aparecer. */
  ok("a tela duplicada de apontamentos não existe mais",
     !fs.existsSync(path.join(RAIZ, "app/painel/apontamentos/page.tsx")) &&
     !fs.existsSync(path.join(RAIZ, "components/PainelApontamentos.tsx")));

  const navSrc = fs.readFileSync(path.join(RAIZ, "lib/nav.ts"), "utf8");
  ok("...e nenhum menu aponta para a rota que saiu",
     !/\/painel\/apontamentos/.test(navSrc));

  /* o balanço anual morava naquela tela: some a tela, some a peça de renovação
     — e ninguém repara, porque número que ninguém procura não faz falta */
  const reformaSrc = fs.readFileSync(path.join(RAIZ, "app/painel/reforma/page.tsx"), "utf8");
  ok("o balanço 'o que a Reforma rendeu' sobreviveu, na Reforma",
     /RendimentoDaCarteira/.test(reformaSrc));

  const ficha = fs.readFileSync(path.join(RAIZ, "components/PainelEmpresa.tsx"), "utf8");
  ok("a ficha da empresa tem as quatro abas, com os apontamentos entre elas",
     /\["decisao"/.test(ficha) && /\["dossie", "Dossiê"\]/.test(ficha) &&
     /\["comparativo", "Comparativo"\]/.test(ficha) && /"apontamentos",/.test(ficha));
  ok("...e a aba mostra quantos pontos estão em aberto, sem precisar abrir",
     /Apontamentos da Reforma · \$\{pendentes\}/.test(ficha));
  /* montar só dentro da aba ativa faria o rótulo saber o número DEPOIS de
     alguém abrir a aba — ou seja, só para quem já não precisava do aviso */
  ok("...e a lista monta mesmo com a aba fechada, senão o número nunca chega",
     /aba === "apontamentos" \? "pb-4" : "hidden"/.test(ficha));

  ok("o cockpit sabe filtrar os pontos da Reforma em aberto",
     cockLib.filtrarPorEtapa(
       [{ id: "a", faixa: "A", apontamentos: 2 }, { id: "b", faixa: "A", apontamentos: 0 }],
       "reforma_pendente"
     ).length === 1);
  /* o lote só pode REGISTRAR que olhou: "não se aplica" tira a empresa do
     relatório anual e "virou serviço" põe dinheiro nele — nenhum dos dois se
     decide sem ler a norma */
  ok("o lote do cockpit marca 'tratado', e só isso",
     /status: "tratado"/.test(cock) &&
     !/status: "nao_se_aplica"/.test(cock) && !/status: "virou_servico"/.test(cock));

  const rotaApont = fs.readFileSync(path.join(RAIZ, "app/api/apontamentos/route.ts"), "utf8");
  ok("a rota resolve os pontos por empresa e só alcança o que está em aberto",
     /corpo\.empresas/.test(rotaApont) && /\.eq\("status", "novo"\)/.test(rotaApont));

  /* nem `truncate` (reticências na primeira linha) nem `line-clamp` (corte
     silencioso na segunda): razão social aparece inteira, quebrando em quantas
     linhas precisar. A trava confere as duas formas de esconder. */
  /* ═══ o que a gravação de 10/08/2026 revelou ═══════════════════════════
     Três defeitos que só apareceram quando uma carteira de teste passou pelo
     caminho inteiro: o Excel comendo o CNAE, a Receita sobrescrevendo o
     arquivo e a faixa C afirmando "baixo risco" sobre empresa desconhecida. */
  ok("CNAE que voltou do Excel como data é reconhecido",
     csvlib.pareceDataNoLugarDoCnae("08/04/4649") === true &&
     csvlib.pareceDataNoLugarDoCnae("02/02/4930") === true);
  ok("...e o CNAE de verdade NÃO é confundido com data",
     csvlib.pareceDataNoLugarDoCnae("4649-4/08") === false &&
     csvlib.pareceDataNoLugarDoCnae("2511-0/00") === false &&
     csvlib.pareceDataNoLugarDoCnae("") === false);

  const receitaLib = await import(path.join(TMP, "receita.js"));
  {
    /* a Receita COMPLETA o que falta... */
    const semCnae = receitaLib.fundir(
      { cnpj: "1", razao_social: "ALFA", cnae_principal: undefined },
      { cnae_principal: "4649-4/08", porte: "EPP" }
    );
    ok("a Receita completa o que o arquivo não trouxe",
       semCnae.cnae_principal === "4649-4/08" && semCnae.porte === "EPP");

    /* ...e NÃO troca o que o escritório declarou */
    const divs = [];
    const comCnae = receitaLib.fundir(
      { cnpj: "2", razao_social: "BETA", cnae_principal: "4649-4/08", regime: "Simples Nacional" },
      { cnae_principal: "5611-2/01", regime: "MEI" },
      divs
    );
    ok("a Receita NÃO sobrescreve o que veio no arquivo",
       comCnae.cnae_principal === "4649-4/08" && comCnae.regime === "Simples Nacional",
       comCnae);
    ok("...e a divergência é registrada, com os dois valores",
       divs.length === 2 &&
       divs.some((d) => d.campo === "regime" && d.do_arquivo === "Simples Nacional" && d.da_receita === "MEI"),
       divs);
    /* a razão social continua com a regra antiga: a do arquivo manda */
    ok("a razão social do arquivo continua vencendo a da Receita",
       receitaLib.fundir({ cnpj: "3", razao_social: "Padaria do Zé" },
                         { razao_social: "JOSE DA SILVA COMERCIO LTDA" }).razao_social === "Padaria do Zé");
  }

  ok("empresa SEM CNAE não é chamada de baixo risco",
     triagem.ROTULO_FAIXA.C === "Análise rápida" &&
     /Sem CNAE para triar/.test(triagem.triar({ cnpj: "x", razao_social: "y" }).motivo),
     triagem.triar({ cnpj: "x", razao_social: "y" }).motivo);

  const zerar = path.join(RAIZ, "app/api/dev/zerar-carteira/route.ts");
  /* a trava é o IMPORT, não a palavra: o comentário da rota cita
     `createAdminClient` justamente para explicar por que ele não está lá, e a
     primeira versão deste teste caiu nessa armadilha */
  ok("o reset da conta de teste existe e é do cliente de SESSÃO",
     fs.existsSync(zerar) &&
     /import \{ createClient \} from "@\/lib\/supabase-server"/.test(fs.readFileSync(zerar, "utf8")) &&
     !/createAdminClient\(/.test(fs.readFileSync(zerar, "utf8")));
  ok("...e exige a frase digitada e a conta declarada de demonstração",
     /APAGAR A CARTEIRA/.test(fs.readFileSync(zerar, "utf8")) &&
     /NEXT_PUBLIC_CONTA_DEMO/.test(fs.readFileSync(zerar, "utf8")));

  /* ═══ a segunda gravação quebrada (10/08/2026) ═══════════════════════════
     O roteiro mandava responder "5%" numa pergunta cujos botões são
     "nenhum · poucos · cerca de um terço · mais da metade". Não existe campo
     livre em pergunta nenhuma do formulário: o valor vem do BOTÃO. E os dois
     únicos botões sem percentual no rótulo não diziam quanto valiam — o
     contador clicava "quase todos" e o motor gravava 0,92 sem que nada na tela
     explicasse de onde vinha a "receita qualificada" da linha de baixo. */
  const formOpcoes = fs.readFileSync(path.join(RAIZ, "components/FormAnalise.tsx"), "utf8");
  ok("as opções qualitativas dizem quanto valem",
     /\["quase todos", 0\.92, "mais de 90%"\]/.test(formOpcoes) &&
     /\["poucos", 0\.15, "uns 15%"\]/.test(formOpcoes));
  /* equivalência é TEXTO e não `Math.round(v*100)`: o valor é ponto
     representativo da faixa, não medida — "92%" fingiria precisão */
  ok("...e a equivalência é declarada, não calculada do valor",
     !/Math\.round\(v \* 100\)/.test(formOpcoes));
  /* "sim"/"não" valem 1 e 0, "com esforço" vale 2: mostrar percentual ali
     seria pior do que não mostrar nada */
  ok("...e as perguntas que não são percentuais continuam sem número",
     /\["sim", 1\], \["não", 0\]/.test(formOpcoes) &&
     /\["com esforço", 2\]/.test(formOpcoes));

  ok("a razão social não é mais cortada na fila",
     !/truncate text-\[13\.5px\] font-semibold/.test(cock) &&
     !/line-clamp-\d[^"]*text-\[13\.5px\] font-semibold/.test(cock) &&
     /break-words text-\[13\.5px\] font-semibold/.test(cock));

  const form = fs.readFileSync(path.join(RAIZ, "components/FormAnalise.tsx"), "utf8");
  ok("premissa estimada vira TAREFA numerada, não só aviso de estado",
     /confirme antes de emitir/.test(form) && /Salve a an\u00e1lise/.test(form));
  ok("empresa sem análise nenhuma também recebe instrução",
     /semAnalise/.test(form) && /ainda n\u00e3o tem an\u00e1lise/.test(form));

  /* ═══ a terceira gravação quebrada (10/08/2026) ══════════════════════════
     Quatro defeitos numa tela só, todos do mesmo tipo: a tela contava uma
     história diferente da que o roteiro contava, e a diferença só apareceu com
     a câmera ligada. */

  /* 1 · O RBT12 CRU. Nascia `String(2400000)` e recebia dígito por dígito sem
     formatação: para saber se eram 2,4 milhões ou 24 milhões era preciso
     contar zero com o olho — num campo que TROCA A ALÍQUOTA e vira número no
     laudo. `mascaraMoeda` acumula centavos da direita para a esquerda (como
     terminal de cartão) em vez de reformatar, que jogaria o cursor para o fim
     a cada tecla e impediria corrigir o meio do número. */
  ok("a receita bruta é digitada com máscara de milhar, não como número cru",
     /mascaraMoeda\(e\.target\.value\)/.test(form) &&
     /valorDaMascara\(rbt12\)/.test(form) &&
     /moedaParaMascara\(rbt12Inicial\)/.test(form));

  /* 2 · O CAMPO DO CRESCIMENTO. Pedia medição do ano que passou; quem não tem
     o número na mão deixa em branco, e em branco o laudo perde a projeção
     inteira. Agora é expectativa declarada — e o nome do campo precisa dizer
     isso, ou vira medição fingida dentro de um documento assinado. */
  /* a negativa roda SEM os comentários: a nota que documenta a mudança cita a
     pergunta antiga entre aspas, de propósito, e um teste que confunde a
     história do defeito com o defeito obriga a apagar a história para ficar
     verde — foi o que quase aconteceu com o `createAdminClient` do reset */
  const formSemNota = form.replace(/\/\*[\s\S]*?\*\//g, "");
  ok("o campo de crescimento pede EXPECTATIVA, não medição do ano passado",
     /Expectativa de crescimento anual/.test(formSemNota) &&
     !/quanto a receita cresceu/i.test(formSemNota));
  ok("...e é isso que viaja para o servidor",
     /crescimento_esperado:/.test(form) &&
     /crescimento_esperado/.test(
       fs.readFileSync(path.join(RAIZ, "app/api/analise/route.ts"), "utf8")
     ));

  /* 3 · A ORDEM DA TELA. O botão ficava DEPOIS do resultado, e o resultado era
     calculado ao vivo: a decisão aparecia enquanto o contador ainda respondia,
     e "salvar" virava burocracia no fim de uma leitura. Invertido, a tela conta
     a história que o laudo depois afirma — você responde, você manda calcular,
     o sistema devolve. A verificação é de POSIÇÃO no arquivo, porque texto
     certo na ordem errada é exatamente o defeito. */
  {
    const posBotao = form.indexOf("Calcular e salvar a análise");
    const posResultado = form.indexOf("A decisão em uma linha");
    ok("o botão de calcular vem ANTES do resultado na tela",
       posBotao > 0 && posResultado > 0 && posBotao < posResultado,
       { posBotao, posResultado });
    ok("...e o resultado fica escondido até mandarem calcular",
       /mostrarResultado = calculou \|\| salvo/.test(form) &&
       /useState\(!semAnalise && !estimada\)/.test(form));
  }

  /* 4 · O CAMINHO "PREENCHER DIRETAMENTE". Escolher preencher e encontrar tudo
     preenchido pelo chute do CNAE é a armadilha que o roteiro existe para
     desarmar. As perguntas passam por `vis`, que devolve NaN enquanto o campo
     não foi tocado — e NaN não casa com botão nenhum. */
  {
    const comVis = (form.match(/valor=\{vis\("/g) || []).length;
    ok("todas as perguntas passam pelo filtro do modo em branco", comVis === 10, comVis);
    /* a soma derivada é o vazamento que sobra: os botões não nascem marcados,
       mas o estado por trás deles tem o padrão do sistema, e a linha
       "receita qualificada = 90% × 78,2% = 70,4%" apareceria com as três
       perguntas acima intocadas — número que ninguém respondeu, no lugar exato
       onde a tela promete que nada vem preenchido */
    ok("...e as somas derivadas não aparecem antes das parcelas",
       /!emBranco \|\| \(tocadas\.has\("b2b"\) && tocadas\.has\("qual\.fora_simples"\) && tocadas\.has\("qual\.sem_aproveitamento"\)\)/.test(form) &&
       /!emBranco \|\| \(tocadas\.has\("cred\.insumos"\) && tocadas\.has\("cred\.servicos"\) && tocadas\.has\("cred\.outros"\)\)/.test(form));
    /* CADA sub-pergunta tem chave própria. Com a chave agregada, um clique em
       "insumos" acendia as outras duas do bloco mostrando `nada` selecionado —
       resposta que ninguém deu, no modo cuja promessa é que nada vem
       preenchido. E o aviso dizia "faltam 3" com seis botões apagados. */
    ok("...e cada sub-pergunta é contada e acesa por si",
       /const CHAVES_OBRIGATORIAS = \[[^\]]*"qual\.fora_simples"[^\]]*"cred\.outros"[^\]]*\]/s.test(form) &&
       (form.match(/tocar\("(qual|cred)", "(qual|cred)\./g) || []).length === 5 &&
       !/valor=\{vis\("(qual|cred)",/.test(form));
    ok("...e o botão trava enquanto faltar resposta, para não gravar padrão como premissa",
       /const faltamResponder = emBranco/.test(form) &&
       /disabled=\{salvando \|\| \(segregar && !fechado\) \|\| faltamResponder > 0\}/.test(form));
  }

  /* 5 · O EM BRANCO SÓ VALE ANTES DE SALVAR. `caminhoPremissas` é estado de
     tela e sobrevive ao salvamento; sem a guarda, quem escolhesse "preencher
     diretamente" e salvasse veria a própria análise recém-gravada em branco de
     novo — a tela apagando o trabalho que ela acabou de aceitar. */
  ok("o formulário em branco só é oferecido enquanto não há análise do contador",
     /emBranco=\{caminhoPremissas === "direto" && \(!a \|\| estimada\)\}/.test(painel));
  ok("...e cada porta do roteiro tem um destino para onde rolar",
     /coletaRef = useRef<HTMLDivElement>\(null\)/.test(painel) &&
     /if \(c === "coleta"\) coletaRef\.current\?\.scrollIntoView/.test(painel) &&
     /<div ref=\{coletaRef\}>/.test(painel));
}

/* ══ O LAUDO NÃO PODE DISCORDAR DE SI MESMO (10/08/2026) ═══════════════════
   Achados relendo um laudo emitido de verdade. Nenhum deles muda a saída — são
   todos de leitura, que é onde o documento se defende ou não numa reunião. ══ */
secao("O laudo diz a mesma coisa uma vez só");
{
  const folha = fs.readFileSync(path.join(RAIZ, "components/LaudoFolha.tsx"), "utf8");
  const laudoTs = fs.readFileSync(path.join(RAIZ, "lib/laudo.ts"), "utf8");

  /* 1 · "GANHO ESTIMADO NO ANO" era o topo da faixa de negociação chamado de
     resultado — quatro linhas abaixo de "+R$ 55.376 de tributo". Era a linha
     que fazia o laudo parecer que se contradizia, e ela promete resultado, que
     o produto não pode prometer. */
  ok("o laudo não chama o teto da negociação de ganho estimado",
     !/Ganho estimado no ano/.test(folha));
  ok("...e mostra as DUAS pontas da faixa, com o piso valendo zero",
     /Se o repasse ficar no mínimo que equilibra/.test(folha) &&
     /Se o repasse for negociado até o limite do cliente/.test(folha) &&
     /R\$ 0/.test(folha));
  ok("...dizendo que o teto não é previsão",
     /não é previsão/.test(folha) && /nada neste laudo garante/.test(folha));
  ok("...e nem a nota do valor bruto volta a chamá-lo de ganho",
     !/O ganho acima é/.test(folha) && /O teto acima é/.test(folha));
  ok("...e a outra ponta é a absorção, nomeada como ponta da mesma faixa",
     /Se não houver repasse nenhum, a empresa absorve/.test(folha) &&
     /outra ponta da mesma faixa/.test(folha));

  /* 2 · IRRETRATÁVEL × CANCELÁVEL. A seção 2 dizia "semestral e irretratável" e
     a 9 dizia "cancelável até novembro", sem a frase que reconcilia. Um
     advogado lendo as duas encontra contradição onde há só dois momentos. */
  ok("irretratável e cancelável aparecem reconciliados, não soltos",
     /Irretratável e cancelável não se contradizem/.test(laudoTs) &&
     /iniciado o efeito, vale o semestre inteiro sem volta/.test(laudoTs));
  ok("...e a seção de riscos aponta para a reconciliação em vez de repetir a metade",
     /ANTES de o efeito começar; iniciado o semestre, ela é irretratável/.test(laudoTs));

  /* 3 · MESMA GRANDEZA, MESMAS CASAS. A memória imprimia 10,66% e a nota
     10,7%; o dDAS saía 1,653% na memória e 1,7% na nota; a folga era 4,16 no
     passo 9 e 4,2 nas seções 5 e 7. Quem confere um laudo procura o mesmo
     número em dois lugares — achar dois é achar um erro, mesmo sem erro. */
  ok("a alíquota efetiva sai com as mesmas casas na memória e na nota",
     /Alíquota efetiva do Simples: \$\{pct\(d\.aliquota, 2\)\}/.test(laudoTs));
  ok("o dDAS também — em 1,7% some o dígito que separa um cl de 2,3% de um de 2,4%",
     /= \$\{pct\(d\.das, 3\)\} da receita/.test(laudoTs));
  ok("e a folga da negociação sai com uma casa, como nas seções 5 e 7",
     !/\(Number\(a\.fc\) - liq\) \* 100\)\.toFixed\(2\)/.test(laudoTs));

  /* ═══ A TELA TEM DE DIZER O MESMO QUE O LAUDO QUE ELA GERA ═══════════════
     O laudo parou de chamar o topo da faixa de "ganho"; a tela não foi junto e
     passou horas afirmando um resultado que o documento gerado a partir dela
     recusava afirmar. Duas telas discordando sobre o mesmo número é pior do que
     as duas erradas do mesmo jeito: o contador confere uma contra a outra, e é
     assim que ele perde a confiança nas duas. Este bloco amarra as duas. ══ */
  const formTela = fs.readFileSync(path.join(RAIZ, "components/FormAnalise.tsx"), "utf8");
  /* as negativas rodam SEM comentário — a nota que documenta o conserto cita o
     rótulo antigo entre aspas, de propósito, e um teste que confunde a história
     do defeito com o defeito obriga a apagar a história para ficar verde. Mesma
     armadilha do `createAdminClient` na rota de reset. */
  const semNota = (t) => t.replace(/\/\*[\s\S]*?\*\//g, "");
  ok("a tela da análise não chama o teto da negociação de ganho",
     !/Ganho da empresa se optar/.test(semNota(formTela)));
  for (const [conceito, na] of [
    ["o piso que não gera ganho", /Se o repasse ficar no mínimo que equilibra/],
    ["o teto, condicionado ao cliente", /limite do cliente/],
    ["a absorção como a outra ponta", /Se não houver repasse nenhum, a empresa absorve/],
  ]) {
    ok(`tela e laudo nomeiam ${conceito} do mesmo jeito`,
       na.test(formTela) && na.test(folha), { tela: na.test(formTela), laudo: na.test(folha) });
  }
  ok("...e o payback aponta para o teto nas duas",
     /Em quanto tempo o teto da faixa cobre esse custo/.test(formTela) &&
     /Em quanto tempo o teto da faixa cobre esse custo/.test(folha));
  ok("...e a alíquota efetiva sai com as mesmas casas na tela e no documento",
     /efetiva \$\{pct\(ddas\.aliquota, 2\)\}/.test(formTela));

  /* ═══ A PROVENIÊNCIA CHEGA À TELA E AO DOCUMENTO PELO MESMO CAMINHO ═════
     A regra saiu de dentro do formulário para lib/origem-premissa.ts, com
     suíte própria. O que sobra de estrutural é: a tela usa a regra em vez de
     reimplementá-la, e o painel entrega o que já estava gravado — sem isso, a
     preservação testada lá não acontece aqui. ══════════════════════════════ */
  ok("a tela resolve a origem pela regra compartilhada, sem reimplementar",
     /resolverOrigem\(\{/.test(formTela) &&
     /from "@\/lib\/origem-premissa"/.test(formTela) &&
     !/if \(tocadas\.has\(chave\)\) return "informada";/.test(formTela));
  ok("...e o painel entrega as origens já gravadas, senão não há o que preservar",
     /origensIniciais=\{\(a\?\.parametros\?\.origens/.test(
       fs.readFileSync(path.join(RAIZ, "components/PainelEmpresa.tsx"), "utf8")
     ) &&
     /origensIniciais\?\.\[chave\]/.test(formTela));
  /* uma premissa não fala pelas sete: a linha resumia tudo lendo `b2b`, e num
     caso real as sete se dividiam em quatro estimadas e três do contador */
  ok("o resumo da origem conta as sete, em vez de amostrar a primeira",
     /origem das premissas: \{resumoDasOrigens\}/.test(formTela) &&
     !/ROTULO_ORIGEM\[origemDe\("b2b"\)\]/.test(formTela));
  /* ═══ SEM GANHO NÃO HÁ FAIXA ═════════════════════════════════════════════
     As duas pontas entraram certas no caso S4. No primeiro S2 a tabela dizia
     "no mínimo que equilibra: R$ 0" seguido de "até o limite do cliente: sem
     ganho no cenário" — piso e teto para uma faixa que não existe. Mesmo
     cuidado que `pressaoComercial` toma no motor, e pela mesma razão escrita
     lá: tabela degenerada parece número sem ser. ═══════════════════════════ */
  /* `semNota` de novo, e é a terceira vez hoje: toda nota que documenta um
     conserto cita o texto que saiu, e toda negativa escrita sobre o arquivo
     cru acusa a própria explicação. A regra é a mesma sempre — negativa lê
     código, positiva pode ler o arquivo inteiro. */
  for (const [onde, txt] of [["o laudo", folha], ["a tela", formTela]]) {
    /* A DERIVAÇÃO, não o identificador. A primeira versão testava
       `/temFaixaDeNegociacao/`, que continua casando com
       `const temFaixaDeNegociacao = true` — e foi assim que a sabotagem passou
       batida. Presença de nome não é prova de regra: o que precisa estar preso
       é a origem do valor. */
    const atrib = semNota(txt).match(/temFaixaDeNegociacao\s*=\s*([^;]+);/);
    ok(`${onde} decide a faixa a partir do ganho, não de um literal`,
       atrib != null && /ganho_anual/.test(atrib[1]) && !/^\s*(true|false)\s*$/.test(atrib[1]),
       atrib ? atrib[1].trim() : null);
    ok(`${onde} não desenha piso e teto quando não há faixa`,
       /Não há faixa de negociação neste cenário/.test(txt) &&
       !/sem ganho no cenário/.test(semNota(txt)));
  }

  /* E O DOCUMENTO DESTACA AS DUAS FRACAS — nas DUAS tabelas.
     O laudo tem duas: a curta (faixas C/D) e a longa. A primeira versão desta
     asserção usava `.test()`, que acha uma ocorrência e para — e a sabotagem,
     que troca só a primeira, passou batida. Um teste que prova metade de uma
     regra presente em dois lugares é meio teste. */
  {
    const marcadas = (folha.match(/pr\.origem === "estimada" \|\| pr\.origem === "padrao"/g) || []).length;
    const tabelas = (folha.match(/className=\{`org /g) || []).length;
    ok("o laudo destaca também a premissa que ninguém escolheu",
       tabelas > 0 && marcadas === tabelas,
       { tabelasDePremissa: tabelas, comDestaqueCompleto: marcadas });
  }

  /* ═══ O GRÁFICO ESTAVA COM AS DUAS BARRAS EM UNIDADES DIFERENTES ═════════
     A de cima desenhava `fc` (ganho por operação); a de baixo, `re` (aumento de
     PREÇO). A distância entre elas não era a folga que a frase logo abaixo
     anunciava — 1,8 pontos no desenho contra 2,3 no texto. E a legenda de `fc`
     dizia "teto do aumento de preço", que é fc ÷ (1 − alíquota): 7,8%, não
     7,1%. A tela afirmava um limite de negociação que o laudo contradiz. ══ */
  const gauge = fs.readFileSync(path.join(RAIZ, "components/Gauge.tsx"), "utf8");
  ok("o gráfico desenha as duas barras na mesma régua",
     /const desenhar = isFinite\(reLiquido\) \? reLiquido : re;/.test(gauge) &&
     /larguraRe = \(Math\.min\(isFinite\(desenhar\)/.test(gauge));
  ok("...e não chama o ganho do comprador de teto do aumento de preço",
     !/Teto do aumento de preço/.test(semNota(gauge)));
  ok("...e recebe o repasse líquido de quem o calculou, em vez de refazer a conta",
     /<Gauge re=\{res\.re\} reLiquido=\{res\.re_liquido\} fc=\{res\.fc\} \/>/.test(formTela) &&
     !/1 - .*aliquota/.test(semNota(gauge)));
  /* a folga tem UM dono. Um segundo lugar na tela com o mesmo nome e outro
     arredondamento é o defeito que este conserto acabou de tirar das barras. */
  ok("...e o gráfico não imprime uma segunda versão da folga",
     !/pontos entre as duas barras/.test(semNota(gauge)) &&
     !/toFixed\(1\)/.test(semNota(gauge)));
}

/* ============================ 2a. ROTAS CITADAS NOS E-MAILS EXISTEM? ===== */
secao("Links das réguas apontam para rotas que existem");
{
  // O painel foi de treze rotas para uma. As réguas semeadas na 0020 ficaram
  // apontando para /painel/entrega, /fila, /lote e /radar — quatro 404 dentro
  // de e-mails de ativação e conversão, mandados justamente para quem tinha
  // acabado de decidir agir. Nada na tela acusa isso, e nenhum teste de
  // runtime pega: o link é DADO, mora no banco e no seed.
  const migr = path.join(RAIZ, "supabase", "migrations");
  const rotas = new Set();
  for (const f of fs.readdirSync(migr).filter((f) => f.endsWith(".sql"))) {
    const txt = fs.readFileSync(path.join(migr, f), "utf8");
    for (const m of txt.matchAll(/\{\{\s*link_app\s*\}\}\/painel\/([a-z-]+)/g)) {
      // a 0025 é a que CONSERTA — o que ela cita entre aspas de regexp não conta
      if (f.startsWith("0025")) continue;
      rotas.add(m[1]);
    }
  }
  const existem = new Set(
    fs.readdirSync(path.join(RAIZ, "app", "painel"), { withFileTypes: true })
      .filter((d) => d.isDirectory())
      .map((d) => d.name)
  );
  const mortas = [...rotas].filter((r) => !existem.has(r));
  ok(`rotas citadas nos e-mails: ${[...rotas].join(", ") || "(nenhuma)"}`, true);
  ok("nenhum e-mail semeado aponta para rota removida", mortas.length === 0, mortas);
  if (mortas.length > 0) {
    ok("(a migration 0025 reescreve esses links no banco — rode-a)", false, mortas);
  }
}

/* ===================================== 2b. CNPJs COLADOS (importação) ==== */
secao("CNPJs colados — o caminho sem export do sistema");
{
  // A primeira versão desta extração buscava o padrão do CNPJ no texto inteiro
  // com uma expressão que aceitava espaço no meio. Como quebra de linha é
  // espaço, ela emendava linhas seguidas num número de 42 dígitos e devolvia
  // ZERO — no caso mais comum de todos. Estes casos existem para isso não
  // voltar: cada um é uma forma real de o contador colar a carteira dele.
  const casos = [
    ["um por linha, formatado", "11.222.333/0001-81\n07.526.557/0001-00\n22.333.444/0001-55", 3],
    ["um por linha, só dígitos", "11222333000181\n07526557000100", 2],
    ["separados por vírgula", "11.222.333/0001-81, 07.526.557/0001-00", 2],
    ["separados por ponto e vírgula", "11222333000181;07526557000100", 2],
    ["colado de planilha, com o nome junto",
      "Distribuidora Aurora\t11.222.333/0001-81\nRestaurante X\t07.526.557/0001-00", 2],
    ["CPF no meio não vira CNPJ", "CPF 123.456.789-00\n11.222.333/0001-81", 1],
    ["telefone não vira CNPJ", "(11) 98765-4321 e 11.222.333/0001-81", 1],
    ["data e valor em reais não viram CNPJ", "01/01/2027 R$ 1.234.567,89 11.222.333/0001-81", 1],
    ["texto sem documento nenhum", "nenhum documento aqui", 0],
    ["vazio", "", 0],
  ];
  for (const [nome, entrada, esperado] of casos) {
    const achados = csvlib.extrairCnpjs(entrada);
    ok(nome, achados.length === esperado, `${achados.length} ≠ ${esperado}`);
  }

  // o CSV montado precisa passar pelo MESMO parser do upload, senão o caminho
  // colado seria um segundo jeito de ler carteira para manter em dia
  const colado = csvlib.parsearCarteira(
    csvlib.csvDeCnpjs(csvlib.extrairCnpjs("11.222.333/0001-81\n07.526.557/0001-00"))
  );
  ok("o texto colado atravessa o parser do upload", colado.linhas.length === 2, colado.linhas.length);
  ok("sem razão social, entra com o rótulo (a Receita completa depois)",
     colado.linhas[0].razao_social === "(sem razão social)", colado.linhas[0].razao_social);
  ok("CNPJ com dígito verificador errado é descartado pelo parser",
     csvlib.parsearCarteira(csvlib.csvDeCnpjs(["11222333000199"])).descartadas === 1);
}

/* ================================================ 3. OS 15 CENÁRIOS ===== */
secao("Cenários da decisão");
const CEN = [
  ["C01", { b2b: .9, qual: .92, cred: .7, folha: .12, preco: 3, conc: 1, exig: 1 }, null, "S4"],
  ["C02", { b2b: .9, qual: .9, cred: .05, folha: .35, preco: 1, conc: 1, exig: 0 }, null, "S2"],
  ["C03", { b2b: .05, qual: .5, cred: .6, folha: .18, preco: 2, conc: 0, exig: 0 }, null, "S1"],
  ["C04", { b2b: .5, qual: .25, cred: .5, folha: .2, preco: 2, conc: 0, exig: 0 }, null, "S1"],
  ["C05", { b2b: .7, qual: .7, cred: .4, folha: .2, preco: 2, conc: 1, exig: 0 }, null, "S3"],
  ["C06", { b2b: .8, qual: .9, cred: .9, folha: .1, preco: 2, conc: 1, exig: 1 }, null, "S5"],
  /**
   * C07 MUDOU DE S1 PARA S3 em 05/08/2026, e a mudança é a correção do repasse.
   *
   *   re 8,923% · re × (1 − 8,8%) = 8,138% · fc 7,327% · 1,2 × fc = 8,792%
   *
   * O repasse CRU estourava o teto por 13 centésimos de ponto. O que o
   * comprador SENTE — descontado o crédito que o próprio reajuste gera — cabe
   * dentro da banda. É o caso limítrofe que a correção existe para acertar: a
   * empresa recebia "não optar" por causa de um efeito que não existe.
   */
  ["C07", { b2b: .85, qual: .85, cred: .1, folha: .4, preco: 2, conc: 1, exig: 1 }, null, "S3"],
  ["C08", { b2b: .9, qual: .95, cred: .65, folha: .15, preco: 3, conc: 1, exig: 1 }, null, "S4"],
  ["C09", { b2b: .6, qual: .5, cred: .5, folha: .2, preco: 3, conc: 1, exig: 0 }, null, "S1"],
  ["C10", { b2b: .6, qual: .49, cred: .5, folha: .2, preco: 3, conc: 1, exig: 0 }, null, "S1"],
  ["C11", { b2b: .9, qual: .9, cred: .7, folha: .15, preco: 0, conc: 1, exig: 1 }, null, "S2"],
  ["C12", { b2b: .8, qual: .9, cred: .6, folha: .15, preco: 3, conc: 1, exig: 1 }, 3550000, "S3"],
  ["C13", { b2b: .8, qual: .9, cred: .6, folha: .15, preco: 3, conc: 1, exig: 1 }, 1200000, "S4"],
  ["C14", { b2b: .05, qual: .9, cred: .85, folha: .1, preco: 3, conc: 1, exig: 0 }, null, "S1"],
  ["C15", { b2b: .9, qual: .05, cred: .6, folha: .15, preco: 3, conc: 1, exig: 0 }, null, "S1"],
];
for (const [id, r, rbt12, esperada] of CEN) {
  const res = motor.decidir(r, { ...motor.PARAMETROS_2027, rbt12 });
  ok(`${id} → ${esperada}`, res.saida === esperada, res.saida);
}
ok("C12 é o único que cai na banda do sublimite",
   motor.decidir(CEN[11][1], { ...motor.PARAMETROS_2027, rbt12: 3550000 }).banda_sublimite === true &&
   motor.decidir(CEN[12][1], { ...motor.PARAMETROS_2027, rbt12: 1200000 }).banda_sublimite === false);

/* ====================================== 4. OS 10 DE SEGREGAÇÃO ========== */
secao("Cenários de receita segregada");
const R_G = { b2b: .8, qual: .9, cred: .35, folha: .15, preco: 2, conc: 1, exig: 0 };
const SEG = [
  ["G01", [{ anexo: 2, share: .7 }, { anexo: 1, share: .3 }], 2, 1800000,
   { b2b: .85, qual: .9, cred: .55, folha: .16, preco: 2, conc: 1, exig: 0 }, 0.014145, "S4", "S4"],
  ["G02", [{ anexo: 3, share: .6 }, { anexo: 1, share: .4 }], 3, 1200000,
   { b2b: .8, qual: .85, cred: .4, folha: .32, preco: 2, conc: 1, exig: 0 }, 0.018449, "S4", "S4"],
  ["G03", [{ anexo: 5, share: .5 }, { anexo: 1, share: .5 }], 5, 1200000, R_G, 0.025104, "S4", "S4"],
  /**
   * G04 e G08: a coluna "pelo cadastro" virou S4. Esses dois cenários existem
   * para mostrar que tratar empresa mista pelo anexo do cadastro TROCA a saída
   * — e continuam mostrando, só que agora o erro aparece em outro par.
   *
   * Pelo Anexo I sozinho: re 6,045% · líquido 5,513% · 0,8 × fc 5,946%.
   * O repasse cru caía DENTRO da banda de fronteira; o líquido fica abaixo
   * dela. Mesma correção do C07, mesmo mecanismo.
   */
  ["G04", [{ anexo: 5, share: .5 }, { anexo: 1, share: .5 }], 1, 1200000, R_G, 0.025104, "S4", "S4"],
  /**
   * G05 e G06 MUDARAM em 05/08/2026, e não por conveniência de teste.
   *
   * São os dois únicos cenários deste gabarito com receita de serviço na 5ª
   * faixa — ou seja, os dois em que o TETO DE 5% DO ISS morde (nota de rodapé
   * dos Anexos XX e XXI da LC 214/2025). O excedente do ISS é redistribuído aos
   * tributos federais INCLUSIVE à CBS, então sai MAIS do DAS do que a tabela
   * sozinha sugeriria.
   *
   *   G05: anexo 3 a 2,4 mi · efetiva 15,7650% > gatilho 14,92537% → morde
   *        0,028759 → 0,029156   (+1,38%)
   *   G06: anexo 4 a 3,0 mi · efetiva 15,8740% > gatilho 12,5%     → morde
   *        anexo 3 a 3,0 mi · efetiva 16,8120% > gatilho 14,92537% → morde
   *        0,030575 → 0,033793   (+10,52%, os dois segmentos afetados)
   *
   * Os outros oito cenários não mudaram um dígito. É assim que se sabe que o
   * que mudou foi a regra do ISS, e não a tabela inteira desandando.
   */
  ["G05", [{ anexo: 3, share: .6 }, { anexo: 5, share: .4 }], 3, 2400000,
   /* G05: re 5,089% caía na banda (0,8 × fc = 4,708%); o líquido 4,641% fica
      abaixo, e a saída sobe de S3 para S4. */
   { b2b: .75, qual: .85, cred: .3, folha: .30, preco: 2, conc: 1, exig: 0 }, 0.029156, "S4", "S3"],
  ["G06", [{ anexo: 4, share: .5 }, { anexo: 3, share: .5 }], 4, 3000000,
   { b2b: .9, qual: .9, cred: .45, folha: .34, preco: 2, conc: 1, exig: 0 }, 0.033793, "S4", "S4"],
  ["G07", [{ anexo: 1, share: .4 }, { anexo: 2, share: .3 }, { anexo: 5, share: .3 }], 1, 2000000,
   { b2b: .85, qual: .9, cred: .5, folha: .18, preco: 2, conc: 1, exig: 0 }, 0.020774, "S4", "S4"],
  ["G08", [{ anexo: 5, share: .5 }, { anexo: 1, share: .5 }], 1, 1200000,
   { ...R_G, preco: 3 }, 0.025104, "S4", "S4"],
  ["G09", [{ anexo: 5, share: .4 }, { anexo: 1, share: .6 }], 1, 1200000,
   { b2b: .75, qual: .9, cred: .3, folha: .15, preco: 2, conc: 1, exig: 0 }, 0.022819, "S3", "S3"],
  ["G10", [{ anexo: 1, share: 1 }], 1, 1200000, R_G, 0.013679, "S4", "S4"],
  /**
   * G11 ENTROU EM 05/08/2026, e ele é a razão de esta suíte existir.
   *
   * Com a correção do repasse (`re × (1 − a)` contra `fc`), G04 e G08 deixaram
   * de divergir: os dois caminhos passaram a dar S4. Aceitar isso e apagar a
   * invariante seria transformar a suíte num carimbo — ela foi escrita para
   * guardar UMA propriedade: tratar empresa mista pelo anexo do cadastro pode
   * TROCAR a decisão, não só mexer no terceiro decimal.
   *
   * A propriedade continua verdadeira; só mudou onde ela aparece. Neste
   * cenário o dDAS vai de 2,5104% (segregado) para 1,3679% (só Anexo I), e a
   * diferença joga o caso de "zona de fronteira" para "não optar".
   */
  ["G11", [{ anexo: 5, share: .5 }, { anexo: 1, share: .5 }], 1, 1200000,
   { b2b: .5, qual: .6, cred: .45, folha: .15, preco: 2, conc: 1, exig: 0 }, 0.025104, "S3", "S1"],
];
for (const [id, mix, cadastro, rbt12, r, dasEsperado, saidaSeg, saidaCad] of SEG) {
  const seg = motor.dDASsegregado(mix, rbt12);
  const uni = motor.dDASefetivo(cadastro, rbt12);
  ok(`${id} dDAS ponderado = ${(dasEsperado * 100).toFixed(3)}%`,
     Math.abs(seg.das - dasEsperado) < 5e-7, seg.das);
  const s1 = motor.decidir(r, { ...motor.PARAMETROS_2027, das: seg.das, rbt12 }).saida;
  const s2 = motor.decidir(r, { ...motor.PARAMETROS_2027, das: uni.das, rbt12 }).saida;
  ok(`${id} saída segregada ${saidaSeg} · pelo cadastro ${saidaCad}`,
     s1 === saidaSeg && s2 === saidaCad, { s1, s2 });
}
/**
 * A INVARIANTE DEIXOU DE SER UMA LISTA, e isso é conserto de teste, não
 * afrouxamento.
 *
 * Ela era `join(",") === "G04,G08"` — uma lista fixa. Quebrou duas vezes hoje
 * por motivo legítimo: a correção do repasse mudou QUAIS cenários divergem,
 * sem tocar na propriedade que a suíte existe para guardar — que tratar empresa
 * mista pelo anexo do cadastro pode TROCAR a decisão.
 *
 * Agora a asserção é a propriedade em si, com uma âncora nomeada: G11 foi
 * construído para demonstrá-la e precisa continuar demonstrando. Se um dia
 * NENHUM cenário divergir, a suíte grita — que é o único caso em que ela
 * realmente deve gritar.
 */
const divergem = SEG.filter(([, , , , , , a, b]) => a !== b).map(([id]) => id);
ok(`tratar pelo anexo do cadastro TROCA a decisão em ${divergem.length} cenário(s)`,
   divergem.length >= 1 && divergem.includes("G11"), divergem);
ok("G10 (um anexo a 100%) devolve o mesmo do caminho antigo",
   motor.dDASsegregado([{ anexo: 1, share: 1 }], 1200000).das === motor.dDASefetivo(1, 1200000).das);

/* ================================ 5. LAUDO DE ANÁLISE SEGREGADA ========= */
secao("Memória de cálculo do laudo com receita segregada");
{
  const mix = [{ anexo: 5, share: 0.5 }, { anexo: 1, share: 0.5 }];
  const ddas = motor.dDASsegregado(mix, 1200000);
  const base = { ...motor.PARAMETROS_2027, das: ddas.das, rbt12: 1200000 };
  const res = motor.decidir(R_G, base);
  const analise = {
    id: "x", rq: res.rq, ch: res.ch, cl: res.cl, re: res.re, fc: res.fc,
    saida: res.saida, prioridade: res.prioridade, respostas: R_G,
    calculado_em: "2026-08-02T12:00:00.000Z",
    parametros: {
      ddas, segmentos: mix, segregado: true, aliquota: base.aliquota, das: ddas.das,
      rbt12: 1200000, anexo: ddas.anexo, sublimite: base.sublimite,
      bandaSublimite: base.bandaSublimite, exercicio: 2027,
    },
  };
  const passos = laudo.memoriaDeCalculo(analise);
  const rotulos = passos.map((p) => p.passo);
  ok("imprime um passo por anexo", rotulos.filter((r) => /^1\.\d/.test(r)).length === 2, rotulos);
  ok("o passo 2 diz que a receita é segregada",
     rotulos.some((r) => r.includes("receita segregada")), rotulos);
  const somaPasso = passos.find((p) => p.passo.includes("receita segregada"));
  ok("o passo 2 mostra a soma ponderada", (somaPasso?.substituicao ?? "").includes("+"), somaPasso?.substituicao);
  ok("o resultado do passo 2 é o dDAS final",
     (somaPasso?.resultado ?? "").includes((ddas.das * 100).toFixed(3).replace(".", ",")),
     somaPasso?.resultado);

  const cond = laudo.condicoesDeValidade(analise);
  ok("condição sobre a composição da receita", cond.some((c) => c.includes("composição da receita")), cond.length);
  ok("condição sobre o fator R (há serviço no mix)", cond.some((c) => c.includes("fator R")), cond.length);

  // e a análise SEM segregação continua com a memória antiga
  const simples = { ...analise, parametros: { ...analise.parametros, ddas: motor.dDASefetivo(1, 1200000), segmentos: null, segregado: false } };
  const p2 = laudo.memoriaDeCalculo(simples).map((p) => p.passo);
  ok("análise de um anexo só mantém o passo 1 de sempre",
     p2.some((r) => r.startsWith("1. Alíquota")) && !p2.some((r) => /^1\.\d/.test(r)), p2);
}

/* =============================================== 6. NAVEGADOR =========== */
secao("Navegador — curso estático e formulário da coleta");
const SITE = process.env.SITE_DIR || "/root/work/enquadria-site";
let chromium = null;
try {
  ({ chromium } = await import("playwright"));
} catch {
  ok("playwright disponível", false, "instale para rodar as checagens de navegador");
}

if (chromium && fs.existsSync(SITE)) {
  const navegador = await chromium.launch({
    executablePath: process.env.CHROMIUM || "/opt/pw-browsers/chromium",
  });

  /* ---- curso: gate, progresso, certificado ---- */
  {
    const ctx = await navegador.newContext({ viewport: { width: 414, height: 900 } });
    const p = await ctx.newPage();
    await p.route("**/api/**", (r) =>
      r.fulfill({ status: 200, contentType: "application/json", body: '{"ok":true,"codigo":"EQ-TEST-0001","emitido_em":"2026-03-15T10:00:00Z"}' })
    );
    await p.goto("file://" + path.join(SITE, "curso/index.html"));

    const medalha = await p.$eval(".cert-medalha svg", (e) => Math.round(e.getBoundingClientRect().width));
    ok("medalhão com CSS = 32px", medalha === 32, medalha);
    await p.evaluate(() => document.querySelectorAll("style,link[rel=stylesheet]").forEach((e) => e.remove()));
    const semCss = await p.$eval(".cert-medalha svg", (e) => Math.round(e.getBoundingClientRect().width));
    ok("medalhão SEM css continua 32px (não vira cartaz)", semCss === 32, semCss);

    await p.goto("file://" + path.join(SITE, "curso/index.html"));
    const refs = await p.evaluate(() =>
      [...document.querySelectorAll('link[rel=stylesheet],script[src]')]
        .map((e) => e.href || e.src).filter((u) => u.includes("assets/")));
    ok("assets carimbados com ?v=", refs.length > 0 && refs.every((u) => /\?v=[0-9a-f]{8}/.test(u)), refs);

    const travados = await p.$$eval(".mat-lock", (e) => e.filter((x) => x.offsetParent !== null).length);
    const livres = await p.$$eval(".mat-link", (e) => e.filter((x) => x.offsetParent !== null).length);
    ok("materiais travados antes do e-mail", travados > 0 && livres === 0, { travados, livres });

    await p.fill('[data-gate-form] input[type=email]', "teste@exemplo.com.br");
    await p.click("[data-gate-form] button");
    // ESPERA POR CONDIÇÃO, NÃO POR RELÓGIO. O gate só libera depois do
    // Promise.allSettled das duas chamadas de rede reais; com um sleep fixo de
    // 400ms este teste falhava sozinho de vez em quando, e teste que grita
    // sem motivo é pior do que teste que não existe — em pouco tempo ninguém
    // olha mais o resultado.
    let livres2 = 0;
    try {
      await p.waitForFunction(
        () => [...document.querySelectorAll(".mat-link")].some((x) => x.offsetParent !== null),
        null,
        { timeout: 8000 }
      );
      livres2 = await p.$$eval(".mat-link", (e) => e.filter((x) => x.offsetParent !== null).length);
    } catch {
      livres2 = 0;
    }
    ok("materiais liberam depois do e-mail", livres2 > 0, livres2);

    const prog = () => p.$eval("[data-prog-texto]", (e) => e.textContent.trim());
    ok("progresso começa em 0", (await prog()) === "0 de 9 aulas", await prog());
    await p.evaluate(() => {
      localStorage.setItem("enquadria_curso_progresso", JSON.stringify([1, 2, 3, 4, 5, 6, 7, 8, 9]));
    });
    await p.reload();
    ok("progresso vai a 9 de 9", (await prog()) === "9 de 9 aulas", await prog());
    const liberado = await p.$eval("[data-cert-liberado]", (e) => !e.hidden);
    ok("certificado libera com 9 de 9", liberado);

    await p.evaluate(() => {
      localStorage.setItem("enquadria_curso_progresso", JSON.stringify([1, 2, 3, 4, 6, 7, 8, 9]));
    });
    await p.reload();
    const bloq = await p.$eval("[data-cert-liberado]", (e) => e.hidden);
    ok("desmarcar uma aula tranca o certificado de novo", bloq);

    // a data que vai ao LinkedIn é a de EMISSÃO
    await p.evaluate(() =>
      localStorage.setItem("enquadria_curso_certificado",
        JSON.stringify({ codigo: "EQ-4KMR-8TQZ", nome: "Fulano de Tal", emitido_em: "2026-03-15T10:00:00Z" })));
    await p.reload();
    const q = Object.fromEntries(
      new URL(await p.getAttribute("[data-cert-linkedin]", "href")).searchParams);
    ok("LinkedIn: mês da EMISSÃO, não de hoje", q.issueYear === "2026" && q.issueMonth === "3", q);
    ok("LinkedIn: código e url de verificação", q.certId === "EQ-4KMR-8TQZ" &&
       q.certUrl === "https://app.enquadria.com.br/certificado/EQ-4KMR-8TQZ", q);
    await ctx.close();
  }

  /* ---- formulário da coleta, servido do próprio pacote do app ---- */
  {
    const html = montarPreviaColeta();
    const ctx = await navegador.newContext({ viewport: { width: 414, height: 900 } });
    const p = await ctx.newPage();
    let enviado = null;
    await p.route("**/api/coleta/**", async (r) => {
      enviado = JSON.parse(r.request().postData());
      await r.fulfill({ status: 200, contentType: "application/json", body: '{"ok":true}' });
    });
    await p.setContent(html);

    const opcoes = await p.$$eval("#p1 button", (bs) => bs.map((b) => b.innerText.replace(/\n/g, " | ")));
    ok("cada opção mostra o percentual equivalente",
       opcoes.length === 5 && opcoes.every((o) => o.includes("%")), opcoes);
    ok("pergunta de sim/não NÃO ganha percentual",
       (await p.$$eval("#p3 button", (bs) => bs.map((b) => b.innerText))).every((t) => !t.includes("%")));
    await ctx.close();
  }

  await navegador.close();
} else if (chromium) {
  ok("pasta do site encontrada", false, SITE);
}

/* ===================================================== RELATÓRIO ======== */
function montarPreviaColeta() {
  // Desenha as perguntas a partir de lib/coleta COMPILADO — é a mesma lista que
  // a página pública usa. Testar contra uma cópia do HTML validaria a cópia.
  const { PERGUNTAS } = coleta;
  const bloco = (p, i) => `
    <div id="p${i + 1}">${p.opcoes.map((o) =>
      `<button>${o.rotulo}${o.equivale ? `<span> ${o.equivale}</span>` : ""}</button>`).join("")}</div>`;
  return `<!doctype html><meta charset="utf-8"><body>${PERGUNTAS.map(bloco).join("")}</body>`;
}

/* ══ O PRODUTO ATRAVESSA OUTUBRO? (08/08/2026) ═══════════════════════════════
   Três defeitos desta frente tinham a mesma forma: a regra existia, estava
   certa, e a tela não a consultava. As fases da janela existiam e o subtítulo
   do cockpit era string fixa. O carimbo do laudo tinha `fixada: false` cravado,
   então publicar a Resolução do Senado deixaria o documento dizendo
   "estimativa, prazo até 31/10/2026" embaixo de um número que já é norma. E a
   rodada nova gravava seis campos, produzindo um laudo mais pobre justamente
   na revisão que o produto vende por e-mail.
   Testar aqui é barato; descobrir em novembro, não. */
secao("Depois da janela — a frase, o carimbo e a segunda rodada");
{
  const janela = await import(path.join(TMP, "janela.js"));
  const params = await import(path.join(TMP, "parametros-analise.js"));

  /* a frase principal da tela segue a fase — antes dizia "até 30 de setembro"
     em março de 2027, ao lado de um selo que já sabia que a fase era outra */
  const frase = (f) => janela.chamadaDaCarteira(f, 12, 40);
  ok("na janela aberta, a frase cita 30 de setembro",
     /30 de setembro/.test(frase("aberta")), frase("aberta"));
  ok("na fase da alíquota, ela para de citar setembro e cita 31/10",
     !/30 de setembro/.test(frase("aliquota")) && /31\/10/.test(frase("aliquota")), frase("aliquota"));
  ok("na fase de cancelamento, cita o prazo de 30/11",
     /30\/11/.test(frase("cancelamento")), frase("cancelamento"));
  ok("em 'proxima', fala da nova janela e não do prazo vencido",
     /nova janela/.test(frase("proxima")) && !/30 de setembro/.test(frase("proxima")), frase("proxima"));
  ok("sem trabalho na fila, a frase é só a contagem da carteira",
     janela.chamadaDaCarteira("aberta", 0, 40) === "40 clientes na carteira.");

  /* o carimbo impresso no laudo passa a saber quando o número virou norma */
  const semNorma = motor.carimboAliquota(0.088, "2026-08-08T00:00:00Z");
  ok("sem origem, o carimbo é o de hoje: estimativa, não fixada",
     semNorma.fixada === false && /Resolução do Senado/.test(semNorma.fonte));
  const comNorma = motor.carimboAliquota(0.091, "2026-11-02T00:00:00Z", {
    fixada: true, fonte: "Resolução do Senado Federal nº 55/2026",
  });
  ok("com a norma publicada, o carimbo cita a norma e marca fixada",
     comNorma.fixada === true && comNorma.fonte === "Resolução do Senado Federal nº 55/2026", comNorma.fonte);
  ok("...e a nota do cenário alternativo deixa de chamá-lo de estimativa declarada",
     !/sensibilidade declarada/.test(comNorma.nota_alternativa), comNorma.nota_alternativa);

  /* a segunda rodada não pode gerar laudo mais pobre que a primeira: o laudo
     não recalcula nada, então o que não for congelado aqui não sai no papel */
  const respostas = { pj: 0.7, credito: 0.8, preco: 3, folha: 0.2 };
  const { resultado, parametros } = params.calcularEcongelar({
    respostas, anexo: 1, rbt12: 1_200_000, exercicio: 2027, param: null,
    origemPremissas: params.ORIGEM_RODADA, agora: "2026-11-02T00:00:00Z",
  });
  for (const campo of ["cenarios", "sensibilidade", "dinheiro", "carimbo", "partilha",
                       "motivo", "fator_r", "origens", "motor", "ddas", "rqMin", "absorcaoMax"]) {
    ok(`a rodada nova congela '${campo}' — o laudo lê e não recalcula`,
       parametros[campo] !== undefined, parametros[campo]);
  }
  ok("...e devolve o resultado do motor junto, para não calcular duas vezes",
     !!resultado.saida, resultado.saida);
  ok("os dois cenários de alíquota vão no congelado", Array.isArray(parametros.cenarios) && parametros.cenarios.length >= 2,
     parametros.cenarios?.length);

  /* a alíquota do banco manda sobre a constante — era o que não tinha porta */
  const comBanco = params.calcularEcongelar({
    respostas, anexo: 1, rbt12: 1_200_000, exercicio: 2027,
    param: { aliquota_cbs: 0.09, aliquota_ibs: 0.001, corte_s1: 0, fronteira_min: 0.8,
             fronteira_max: 1.2, fixada: true, fonte: "Resolução do Senado Federal nº 55/2026" },
    origemPremissas: "contador", agora: "2026-11-02T00:00:00Z",
  }).parametros;
  ok("a alíquota publicada no banco vence a constante do motor",
     Math.abs(comBanco.aliquota - 0.091) < 1e-9, comBanco.aliquota);
  ok("...e a procedência dela viaja para o carimbo do laudo",
     comBanco.carimbo.fixada === true, comBanco.carimbo);
}

/* ══ O ANUÁRIO — a peça de renovação (08/08/2026) ═══════════════════════════
   "Virou serviço" era só um rótulo: mudava a cor do botão e a informação
   morria ali. O que estes casos guardam é o comportamento de um documento que
   vai para a MESA DO CLIENTE do contador — e onde um número errado não é um bug
   de tela, é o escritório cobrando por trabalho que não fez.

   Três invariantes: o total só soma o que foi declarado; o trabalho invisível
   (analisado e descartado) aparece; e o corte de período segue a data do FATO,
   não a do registro. */
secao("O anuário — o que a Reforma exigiu no ano");
{
  const an = await import(path.join(TMP, "anuario.js"));
  const P = an.anoCivil(2026);
  const materia = (titulo) => ({ titulo, resumo: null, o_que_fazer: "providência", fonte: "Res. X", severidade: "alta", publicado_em: null, vigencia_em: null });
  const ponto = (o) => ({
    id: o.id ?? "p", status: o.status, nota: o.nota ?? null,
    criado_em: o.criado_em ?? "2026-03-10T00:00:00Z",
    tratado_em: o.tratado_em ?? null, virou_servico_em: o.virou_servico_em ?? null,
    honorario_centavos: o.honorario ?? null, materia: materia(o.titulo ?? "Norma"),
  });

  const base = [
    ponto({ id: "1", status: "virou_servico", virou_servico_em: "2026-05-02T00:00:00Z", honorario: 35000 }),
    ponto({ id: "2", status: "virou_servico", virou_servico_em: "2026-06-02T00:00:00Z" }), // sem valor
    ponto({ id: "3", status: "nao_se_aplica", tratado_em: "2026-04-01T00:00:00Z" }),
    ponto({ id: "4", status: "superado", tratado_em: "2026-04-02T00:00:00Z" }),
    ponto({ id: "5", status: "novo" }),
  ];
  const a = an.montarAnuario(base, [], P);

  ok("conta as normas que alcançaram a empresa no ano", a.pontos === 5, a.pontos);
  ok("o TRABALHO INVISÍVEL aparece: analisado e descartado é resultado",
     a.descartados === 2, a.descartados);
  ok("conta os serviços prestados", a.servicos === 2, a.servicos);
  ok("o total soma SÓ o que foi declarado", a.honorario_centavos === 35000, a.honorario_centavos);
  ok("...e diz quantos ficaram sem valor, em vez de esconder num total incompleto",
     a.servicos_sem_valor === 1, a.servicos_sem_valor);
  ok("o que segue em aberto é contado à parte", a.abertos === 1, a.abertos);
  ok("as linhas saem em ordem de tempo",
     a.linhas.map((l) => l.quando.slice(0, 7)).join("|") === "2026-03|2026-04|2026-04|2026-05|2026-06",
     a.linhas.map((l) => l.quando.slice(0, 10)));

  /* o desfecho é escrito para o EMPRESÁRIO: "nao_se_aplica" é vocabulário de
     fila de trabalho e não pode chegar ao papel */
  const textos = a.linhas.map((l) => l.desfecho).join(" ");
  ok("nenhum estado interno vaza para o documento",
     !/nao_se_aplica|virou_servico|superado|\bnovo\b/.test(textos), textos);
  ok("o descarte é dito como trabalho feito, não como ausência",
     /não alcança esta empresa/.test(an.desfechoDoPonto("nao_se_aplica").texto));
  ok("só 'virou serviço' é marcado como cobrável",
     an.desfechoDoPonto("virou_servico").cobravel === true &&
     an.desfechoDoPonto("tratado").cobravel === false);

  /* a nota do contador sobre AQUELE cliente vence o texto genérico da norma */
  const comNota = an.montarAnuario(
    [ponto({ id: "n", status: "tratado", tratado_em: "2026-07-01T00:00:00Z", nota: "migramos o emissor em 12/07" })],
    [], P
  );
  ok("a nota do contador vence o texto genérico da norma",
     comNota.linhas[0].detalhe === "migramos o emissor em 12/07", comNota.linhas[0].detalhe);

  /* o corte é pela data do FATO: tratar em janeiro de 2027 um ponto criado em
     dezembro de 2026 tem de aparecer no anuário de 2027, senão o trabalho de
     janeiro some do relatório do ano em que foi feito */
  const virada = [ponto({ id: "v", status: "tratado", criado_em: "2026-12-20T00:00:00Z", tratado_em: "2027-01-15T00:00:00Z" })];
  ok("o ponto tratado em 2027 NÃO entra no anuário de 2026",
     an.montarAnuario(virada, [], an.anoCivil(2026)).pontos === 0);
  ok("...e entra no de 2027, que é quando o trabalho aconteceu",
     an.montarAnuario(virada, [], an.anoCivil(2027)).pontos === 1);

  /* documentos: a prova material do serviço, recortada pelo mesmo período */
  const docs = [
    { tipo: "laudo", numero: 7, em: "2026-09-15T00:00:00Z" },
    { tipo: "termo", numero: null, em: "2025-09-15T00:00:00Z", assinado: true },
  ];
  ok("os documentos são recortados pelo período do relatório",
     an.montarAnuario([], docs, P).documentos.length === 1);

  /* a abertura: o caso mais difícil de cobrar é aquele em que nada precisou
     ser feito, e é o que o cliente mais confunde com "não fizeram nada" */
  const vazio = an.montarAnuario([], [], P);
  const aberturaVazia = an.aberturaDoAnuario(vazio, "ACME LTDA");
  ok("sem nenhuma norma, a abertura afirma o acompanhamento em vez de calar",
     /nenhuma das normas/.test(aberturaVazia) && /também é resultado/.test(aberturaVazia), aberturaVazia);
  const abertura = an.aberturaDoAnuario(a, "ACME LTDA");
  ok("com movimento, a abertura cita o volume, o descarte e os serviços",
     /5 normas/.test(abertura) && /2 foram analisadas/.test(abertura) && /2 viraram serviços/.test(abertura),
     abertura);

  /* a carteira: a pergunta que o próprio código dizia não saber responder */
  const carteira = an.resumirCarteira([
    { empresa_id: "e1", nome: "ACME", anuario: a },
    { empresa_id: "e2", nome: "BETA", anuario: an.montarAnuario([ponto({ id: "b", status: "virou_servico", virou_servico_em: "2026-08-01T00:00:00Z", honorario: 90000 })], [], P) },
    { empresa_id: "e3", nome: "SEM NADA", anuario: vazio },
  ], P);
  ok("empresa sem nenhum ponto não entra na conta da carteira",
     carteira.empresas_tocadas === 2, carteira.empresas_tocadas);
  ok("o total da carteira é a soma do declarado",
     carteira.honorario_centavos === 125000, carteira.honorario_centavos);
  ok("os destaques vêm por dinheiro, para a conversa de renovação começar certo",
     carteira.destaques[0].nome === "BETA", carteira.destaques.map((d) => d.nome));
  ok("e os serviços sem valor continuam visíveis no consolidado",
     carteira.servicos_sem_valor === 1, carteira.servicos_sem_valor);

  ok("R$ sai redondo — honorário não se fala em centavos",
     an.emReaisRedondos(125000) === "R$ 1.250", an.emReaisRedondos(125000));

  /* a ressalva é o que impede o total de ser lido como cobrança, economia ou
     promessa — as três leituras erradas de um número num papel com marca */
  ok("a ressalva nega apuração, cobrança e promessa de resultado",
     /não constitui apuração fiscal/.test(an.RESSALVA_ANUARIO) &&
     /cobrança/.test(an.RESSALVA_ANUARIO) &&
     /resultado futuro/.test(an.RESSALVA_ANUARIO));
  ok("...e deixa claro que o valor foi informado pelo escritório",
     /informados pelo próprio escritório/.test(an.RESSALVA_ANUARIO));
}

/* ================================ 12. O QUE SOBRA DEPOIS DA JANELA ======= */
secao("Radar sem critério e o calendário depois de setembro");
{
  /**
   * ═══════════════════════════════════════════════════════════════════════
   * ALERTA SEM CRITÉRIO ALCANÇAVA A BASE INTEIRA — 08/08/2026.
   * ═══════════════════════════════════════════════════════════════════════
   *
   * `afeta()` devolve `true` quando o critério não tem nenhuma dimensão — a
   * leitura certa para a aba Reforma, que é feed. No cockpit ela vira outra
   * coisa: o item publicado assim gera um apontamento para CADA empresa de
   * CADA escritório, e a fila de trabalho de todo mundo abre com o mesmo
   * aviso. A validação já DESCREVIA isso ("Alcança TODAS as empresas de todos
   * os escritórios") e não bloqueava nada — descrever o estrago não impede o
   * estrago.
   */
  const rf = await import(path.join(TMP, "radar-form.js"));

  const rascunho = (x = {}) => ({
    titulo: "Resolução fixa a janela de setembro",
    resumo: "A opção por apurar IBS/CBS fora do DAS vai de 1º a 30 de setembro de 2026.",
    o_que_fazer: "Abra a carteira e separe quem vende para PJ antes do dia 30.",
    fonte: "https://www.gov.br/receitafederal",
    publicado_em: "2026-08-05", vigencia_em: "2026-09-01",
    severidade: "alta", criterio: {}, ativo: true, no_cockpit: true, ...x,
  });

  ok("alerta sem critério nenhum NÃO publica",
     rf.bloqueado(rf.validar(rascunho())),
     rf.validar(rascunho()));

  ok("...e o erro diz o tamanho do estrago e a saída",
     rf.validar(rascunho()).some((p) => p.bloqueia && /todos os escritórios/.test(p.texto) && /notícia/.test(p.texto)),
     rf.validar(rascunho()));

  ok("com uma dimensão preenchida, o alerta volta a publicar",
     !rf.bloqueado(rf.validar(rascunho({ criterio: { anexos: [3] } }))),
     rf.validar(rascunho({ criterio: { anexos: [3] } })));

  ok("faixa, saída, CNAE ou 'só com análise' bastam — não é o anexo que salva",
     [{ faixas: ["A"] }, { saidas: ["S4"] }, { divisoes_cnae: ["62"] }, { somente_com_analise: true }]
       .every((c) => !rf.bloqueado(rf.validar(rascunho({ criterio: c })))));

  /* notícia é feed, não fila: continua podendo valer para todo mundo */
  ok("notícia sem critério continua publicando — quem decide é o no_cockpit",
     !rf.bloqueado(rf.validar(rascunho({ no_cockpit: false }))),
     rf.validar(rascunho({ no_cockpit: false })));

  /**
   * ═══════════════════════════════════════════════════════════════════════
   * A DATA DA PRÓXIMA JANELA EM DOIS LUGARES — 08/08/2026.
   * ═══════════════════════════════════════════════════════════════════════
   *
   * `lib/reguas.ts` tinha `const MARCOS_PROXIMA = "2027-03"`, cópia à mão do
   * `MARCOS.proxima_prevista` de `lib/janela.ts`. As duas nunca são lidas
   * juntas: uma decide quando a fase vira, a outra entra na chave de dedupe.
   * Mudar a de lá quando a data for publicada e esquecer a daqui não dá erro
   * — a fase muda no dia certo e a chave carimba o mês antigo, então o aviso
   * da janela nova não sai para quem recebeu o da anterior.
   */
  {
    const src = fs.readFileSync(path.join(RAIZ, "lib/reguas.ts"), "utf8");
    ok("a chave de dedupe não repete a data da próxima janela à mão",
       !/MARCOS_PROXIMA\s*=\s*["']\d{4}-\d{2}/.test(src),
       "achei a data escrita à mão em lib/reguas.ts");
    ok("...ela é derivada do MARCOS de lib/janela.ts",
       /import\s*\{[^}]*\bMARCOS\b[^}]*\}\s*from\s*["']\.\/janela["']/.test(src) &&
       /MARCOS_PROXIMA\s*=\s*MARCOS\.proxima_prevista/.test(src),
       "não achei a derivação de MARCOS.proxima_prevista");
  }

  /**
   * ═══════════════════════════════════════════════════════════════════════
   * O SILÊNCIO QUE COMEÇAVA EM 02/03/2027.
   * ═══════════════════════════════════════════════════════════════════════
   *
   * A categoria `janela` cobria `aliquota`, `cancelamento` e `efeito`. A fase
   * `proxima` — para onde o calendário vai e onde ele fica, já que não há fase
   * depois dela — não tinha régua nenhuma: dali em diante sobravam cutucada de
   * inatividade e cobrança.
   */
  {
    const src = fs.readFileSync(path.join(RAIZ, "lib/reguas.ts"), "utf8");
    ok("a fase `proxima` tem régua no planejador",
       /f\.fase\s*===\s*["']proxima["']/.test(src) && /monta\(\s*\n?\s*["']nova_janela["']/.test(src),
       "não achei o disparo da régua `nova_janela` na fase proxima");

    const mig = path.join(RAIZ, "supabase/migrations/0069_regua_da_proxima_janela.sql");
    const sql = fs.existsSync(mig) ? fs.readFileSync(mig, "utf8") : "";
    ok("o texto da régua nova está no banco, não no código",
       sql.includes("'nova_janela'") && /on conflict \(chave\) do nothing/.test(sql),
       sql === "" ? "migration 0069 não encontrada" : "faltou a chave ou o on conflict");
    ok("e o e-mail da janela prevista não promete resultado nem anuncia data não publicada",
       sql !== "" && !/economia|economizar|garantid[ao]|blindagem/i.test(sql) &&
       /depende de publicação/.test(sql),
       "o corpo da régua promete resultado ou trata a previsão como norma");
  }
}

/* ══ A PÁGINA QUE PROVA QUE O PRODUTO NÃO MENTE (08/08/2026) ═══════════════
   `/exemplo` é pública e o argumento dela é "confira com os seus olhos". Ela
   afirmava, em `lib/exemplo.ts` e na própria tela, que os CNPJs fictícios têm
   dígito verificador válido — e DEZ dos doze não tinham. A página não quebrava
   porque `triar()` não valida DV, mas qualquer contador que colasse um daqueles
   números no importador via a linha ser descartada pelo próprio produto.
   Afirmação verificável e falsa é o pior defeito que uma página de prova pode
   ter, e é o tipo de coisa que volta sozinha na próxima empresa inventada. */
secao("A carteira de exemplo é verificável");
{
  const ex = await import(path.join(TMP, "exemplo.js"));
  const cnpjlib = await import(path.join(TMP, "cnpj.js"));
  const carteira = ex.CARTEIRA_EXEMPLO;
  ok("a carteira de exemplo tem as doze empresas que a página anuncia",
     carteira.length === 12, carteira.length);
  const invalidos = carteira.filter((e) => !cnpjlib.cnpjValido(e.cnpj)).map((e) => e.cnpj);
  ok("TODOS os CNPJs do exemplo passam no dígito verificador",
     invalidos.length === 0, invalidos);
  /* e continuam fictícios: DV válido não pode virar desculpa para usar CNPJ de
     empresa real numa página aberta */
  ok("nenhum deles é o CNPJ de conferência usado nos testes de CNPJ",
     !carteira.some((e) => e.cnpj === "33000167000101"));
}

/* ══ UMA FRASE, NÃO SETE (08/08/2026) ══════════════════════════════════════
   A única frase idêntica nas seis páginas públicas estava no RODAPÉ. O H1 da
   home, o de /precos e o de /como-funciona vendiam três produtos diferentes, e
   a frase que de fato diferencia vivia no lead do hero e em nenhum outro lugar.
   Um contador decide em cinco segundos se aquilo é para ele; sete versões
   significam que nenhuma foi testada. Isto trava a decisão: a manchete das três
   páginas passa a falar da mesma coisa, e o texto vive em lib/proposta-de-valor. */
secao("A frase do produto é uma só");
{
  const pv = await import(path.join(TMP, "proposta-de-valor.js"));
  const home = fs.readFileSync(path.join(RAIZ, "app/page.tsx"), "utf8");
  const precos = fs.readFileSync(path.join(RAIZ, "app/precos/page.tsx"), "utf8");
  const como = fs.readFileSync(path.join(RAIZ, "app/como-funciona/page.tsx"), "utf8");

  ok("a home lidera pela carteira documentada, não pela triagem",
     /<h1>Saia da janela com a .*carteira inteira documentada/.test(home));
  ok("/precos parou de liderar pelo preço",
     !/<h1>Uma análise cobrada paga o ano/.test(precos) &&
     /<h1>O preço de um cliente, para documentar a carteira inteira/.test(precos));
  ok("/como-funciona fala do mesmo produto que a home",
     /<h1>Da carteira inteira ao documento de cada cliente/.test(como));

  /* as três manchetes têm de dizer "carteira": é o substantivo da promessa, e
     é o que estava diferente em cada página */
  for (const [nome, txt] of [["home", home], ["precos", precos], ["como-funciona", como]]) {
    const h1 = (txt.match(/<h1>(.*?)<\/h1>/) || [])[1] ?? "";
    ok(`a manchete de ${nome} fala da carteira`, /carteira/i.test(h1), h1.slice(0, 80));
  }

  /* e o texto canônico existe num lugar só, para a oitava versão não nascer
     escrita direto numa página */
  ok("a frase canônica menciona a carteira documentada",
     /carteira inteira documentada/.test(pv.TITULO), pv.TITULO);
  ok("o lead diz que a MAIORIA não precisa decidir — a parte que o mercado não vê",
     /maioria não precisa/.test(pv.LEAD));
  ok("a distinção nomeia a categoria concorrente sem citar marca",
     /Simulador calcula uma empresa/.test(pv.DISTINCAO) && !/\b(SAP|Domínio|Alterdata|Contmatic)\b/i.test(pv.DISTINCAO));
  /**
   * O PRO NÃO PODE VENDER O QUE JÁ É GRÁTIS — 08/08/2026.
   *
   * A lista do plano pago anunciava "Relatório do escritório", "Dossiê por
   * empresa" e "Radar da transição". Nenhum dos três tem gate: `situacaoPlano`
   * só é consultado na emissão de laudo, na coleta, no comparativo impresso e
   * no estudo de abertura impresso — as outras telas abrem para qualquer conta.
   * Vender o que a pessoa já tem não converte ninguém e queima a lista inteira
   * no dia em que ela percebe.
   *
   * O teste lê as ROTAS, não a página: se alguém criar o gate de verdade, o
   * item volta a poder ser anunciado, e este teste passa a permitir.
   */
  /* o anchor evita as aspas escapadas do HTML dentro da string do .tsx:
     casar `\\"` em regex de arquivo lido como texto é a receita de teste
     que passa a não testar nada */
  const listaPro = (precos.match(/plan pro[\s\S]*?<\/ul>/) || [""])[0];
  const gates = fs.readFileSync(path.join(RAIZ, "lib/plano.ts"), "utf8");
  const temGate = (rota) => {
    const arq = path.join(RAIZ, rota);
    return fs.existsSync(arq) && /situacaoPlano|bloqueado_por_plano/.test(fs.readFileSync(arq, "utf8"));
  };
  ok("o gate do plano existe e é do servidor", /export function situacaoPlano/.test(gates));
  ok("a lista do PRO não anuncia o relatório do escritório, que não tem gate",
     !/Relatório do escritório/.test(listaPro) || temGate("app/doc/relatorio/page.tsx"));
  ok("...nem o dossiê por empresa",
     !/Dossiê por empresa/.test(listaPro) || temGate("app/api/dossie/route.ts"));
  ok("...nem o radar da transição",
     !/Radar da transição/.test(listaPro) || temGate("app/api/radar/route.ts"));
  /* e o que ela anuncia tem de ser o que o servidor realmente cobra */
  ok("a lista do PRO lidera pelo entregável que o gate protege",
     /Laudos ilimitados/.test(listaPro), listaPro.slice(0, 120));
  ok("o comparativo e a abertura são vendidos como IMPRESSOS, que é o que muda",
     /impressos/.test(listaPro));

  /* nada da proposta de valor pode prometer resultado */
  const tudo = [pv.TITULO, pv.LEAD, pv.CURTA, pv.DISTINCAO, ...pv.PROVAS.map((p) => p.texto)].join(" ");
  ok("nenhuma peça da proposta promete economia, ganho ou garantia",
     !/econom|garant|lucro|retorno garantido|blindagem/i.test(tudo), tudo.slice(0, 120));
}

function fim() {
  secao("Resultado");
  const total = passou + falhas;
  const resumo = falhas === 0
    ? `TUDO PASSOU — ${passou} verificações automáticas`
    : `${falhas} FALHA(S) em ${total} verificações`;
  console.log("\n" + resumo);
  console.log(
    "\nO que este executor NÃO cobre, e continua na sua lista:\n" +
    "  · importar de verdade, RLS, emitir laudo/termo, assinar, gravar coleta,\n" +
    "    cota de plano — tudo isso precisa do Supabase no ar;\n" +
    "  · o cache do .htaccess, que depende do Apache do HostGator;\n" +
    "  · salvar o certificado no perfil do LinkedIn;\n" +
    "  · o que só o olho julga: se está claro, se cabe, se está bonito."
  );
  linhas.push("", resumo);
  fs.writeFileSync(path.join(RAIZ, "testes", "ultimo-relatorio.txt"), linhas.join("\n") + "\n");
  console.log(`\nrelatório em testes/ultimo-relatorio.txt`);
  fs.rmSync(TMP, { recursive: true, force: true });
  process.exit(falhas === 0 ? 0 : 1);
}

fim();
